# =====================================================================
# JumpCloud Device Enrollment - user-session UI (WPF)
#
# Launched in the logged-on user's session by the SYSTEM orchestrator.
# Screens: WELCOME -> ACCOUNT_ENTRY -> (VERIFYING -> LINKING) -> SUCCESS
# with AUTH_FAILED / BIND_FAILED / BLOCKED / defer side paths.
#
# Credential handling: the password exists only inside this process.
# It is read as a SecureString, used once for the LDAPS bind (in a
# background runspace so the UI stays responsive), then disposed. It is
# never written to the IPC channel, logs, disk, or registry.
# =====================================================================
param(
    [string]$ConfigPath = 'C:\ProgramData\JumpCloudEnrollment\config.runtime.json'
)

# --- WPF requires STA; relaunch if the host is MTA -------------------
if ([System.Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList @(
        '-NoProfile', '-Sta', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
        '-File', "`"$PSCommandPath`"", '-ConfigPath', "`"$ConfigPath`"")
    exit 0
}

$ErrorActionPreference = 'Stop'
$script:StartupSw = [System.Diagnostics.Stopwatch]::StartNew()
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml, System.Windows.Forms
$script:SoftwareRender = $false

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ModulesDir = Join-Path (Split-Path -Parent $ScriptRoot) 'Modules'
Import-Module (Join-Path $ModulesDir 'JCEnrollment.Logging.psm1') -Force
Import-Module (Join-Path $ModulesDir 'JCEnrollment.Ipc.psm1') -Force

# UI log lives in the user's own profile (the machine Logs dir is
# restricted to SYSTEM/Administrators).
Initialize-JCLog -Path (Join-Path $env:LOCALAPPDATA 'JumpCloudEnrollment\ui.log') -Component 'UI'

try {
    $cfg = Get-Content -Path $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
}
catch {
    Write-JCLog "Cannot read runtime config at ${ConfigPath}: $($_.Exception.Message)" 'ERROR'
    exit 1
}

Write-JCLog "UI started (version $($cfg.AppVersion))"

# On machines with no usable GPU - RDP, VDI, most managed laptops in a
# remote session - WPF probes for Direct3D at first window creation and
# can stall 20-30 seconds before falling back to software. Forcing
# software rendering up front avoids that probe so the window is
# responsive the instant it appears. CRITICAL: decide this WITHOUT
# reading RenderCapability.Tier - that read is itself what triggers the
# graphics-stack init and the stall. Detection is by remote-session flag
# (cheap, no graphics init) plus an optional config override.
try {
    $remoteSession = [System.Windows.Forms.SystemInformation]::TerminalServerSession
    $forceSoftware = $false
    try { if ($cfg.Ui.ForceSoftwareRender -eq $true) { $forceSoftware = $true } } catch { }
    if ($remoteSession -or $forceSoftware) {
        [System.Windows.Media.RenderOptions]::ProcessRenderMode = `
            [System.Windows.Interop.RenderMode]::SoftwareOnly
        $script:SoftwareRender = $true
    }
}
catch { }
Write-JCLog ("Render mode: {0} (decided at {1} ms)" -f `
    ($(if ($script:SoftwareRender) { 'software (RDP/remote/no-GPU)' } else { 'hardware' })), `
    $script:StartupSw.ElapsedMilliseconds)

# --- Config shortcuts ------------------------------------------------
$IpcDir     = [string]$cfg.Paths.IpcDir
$ReqPath    = Join-Path $IpcDir 'request.json'
$StatusPath = Join-Path $IpcDir 'status.json'
$HbUiPath   = Join-Path $IpcDir 'heartbeat_ui.txt'
$HbSysPath  = Join-Path $IpcDir 'heartbeat_system.txt'

$CompanyName    = [string]$cfg.Ui.CompanyName
$SupportContact = [string]$cfg.Ui.SupportContact
$AccentHex      = [string]$cfg.Ui.AccentColor
if ([string]::IsNullOrWhiteSpace($AccentHex)) { $AccentHex = '#0E8A5F' }

$ResolveTimeoutSec = 45
$BindingTimeoutSec = 300
try { if ([int]$cfg.Timeouts.ResolveTimeoutSeconds -gt 0) { $ResolveTimeoutSec = [int]$cfg.Timeouts.ResolveTimeoutSeconds } } catch { }
try { if ([int]$cfg.Timeouts.BindingStatusTimeoutSeconds -gt 0) { $BindingTimeoutSec = [int]$cfg.Timeouts.BindingStatusTimeoutSeconds } } catch { }

$AllowDefer = $true
try { if ($cfg.Defer.AllowDefer -eq $false) { $AllowDefer = $false } } catch { }
$DeferMinutes = 120
try { if ([int]$cfg.Defer.Minutes -gt 0) { $DeferMinutes = [int]$cfg.Defer.Minutes } } catch { }

$TestEnabled = $false
$SuppressSignOut = $false
try {
    if ($cfg.Test -and $cfg.Test.Enabled -eq $true) {
        $TestEnabled = $true
        if ($cfg.Test.SuppressSignOut -eq $true) { $SuppressSignOut = $true }
    }
} catch { }

# --- Accent shade helpers --------------------------------------------
function Get-ShadedHex {
    param([string]$Hex, [double]$Factor)
    $c = [System.Windows.Media.ColorConverter]::ConvertFromString($Hex)
    $r = [byte][Math]::Max(0, [Math]::Min(255, $c.R * $Factor))
    $g = [byte][Math]::Max(0, [Math]::Min(255, $c.G * $Factor))
    $b = [byte][Math]::Max(0, [Math]::Min(255, $c.B * $Factor))
    return ('#{0:X2}{1:X2}{2:X2}' -f $r, $g, $b)
}
function Get-TintedHex {
    # Blend toward white for the light accent surface.
    param([string]$Hex, [double]$Amount)
    $c = [System.Windows.Media.ColorConverter]::ConvertFromString($Hex)
    $r = [byte]($c.R + (255 - $c.R) * $Amount)
    $g = [byte]($c.G + (255 - $c.G) * $Amount)
    $b = [byte]($c.B + (255 - $c.B) * $Amount)
    return ('#{0:X2}{1:X2}{2:X2}' -f $r, $g, $b)
}
$AccentDark   = Get-ShadedHex -Hex $AccentHex -Factor 0.85
$AccentDarker = Get-ShadedHex -Hex $AccentHex -Factor 0.72
$AccentLight  = Get-TintedHex -Hex $AccentHex -Amount 0.90

# =====================================================================
# XAML
# =====================================================================
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="JumpCloud Account Setup"
        Width="480" SizeToContent="Height"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize"
        Background="#F3F4F6" FontFamily="Segoe UI"
        UseLayoutRounding="True" TextOptions.TextFormattingMode="Display"
        AutomationProperties.AutomationId="JCEnrollWindow">
  <Window.Resources>
    <Style x:Key="PrimaryButton" TargetType="Button">
      <Setter Property="Background" Value="__ACCENT__"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="16,11"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="HorizontalAlignment" Value="Stretch"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}"
                    CornerRadius="8" Padding="{TemplateBinding Padding}"
                    BorderThickness="2" BorderBrush="Transparent">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="bd" Property="Background" Value="__ACCENT_DARK__"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter TargetName="bd" Property="Background" Value="__ACCENT_DARKER__"/>
              </Trigger>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="bd" Property="BorderBrush" Value="#111827"/>
              </Trigger>
              <Trigger Property="IsEnabled" Value="False">
                <Setter TargetName="bd" Property="Background" Value="#9CA3AF"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="SecondaryButton" TargetType="Button">
      <Setter Property="Background" Value="Transparent"/>
      <Setter Property="Foreground" Value="#374151"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Padding" Value="16,10"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="HorizontalAlignment" Value="Stretch"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}"
                    CornerRadius="8" Padding="{TemplateBinding Padding}"
                    BorderThickness="1" BorderBrush="#D1D5DB">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="bd" Property="Background" Value="#F3F4F6"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter TargetName="bd" Property="Background" Value="#E5E7EB"/>
              </Trigger>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="bd" Property="BorderBrush" Value="#111827"/>
                <Setter TargetName="bd" Property="BorderThickness" Value="2"/>
                <Setter TargetName="bd" Property="Padding" Value="15,9"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="LinkButton" TargetType="Button">
      <Setter Property="Background" Value="Transparent"/>
      <Setter Property="Foreground" Value="__ACCENT__"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="4,2"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="Transparent" CornerRadius="4" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Foreground" Value="__ACCENT_DARK__"/>
              </Trigger>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="bd" Property="Background" Value="#E5E7EB"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="InputText" TargetType="TextBox">
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Foreground" Value="#111827"/>
      <Setter Property="Padding" Value="10,9"/>
      <Setter Property="Background" Value="#FFFFFF"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TextBox">
            <Border x:Name="bd" Background="{TemplateBinding Background}" BorderBrush="#D1D5DB"
                    BorderThickness="1" CornerRadius="6">
              <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="bd" Property="BorderBrush" Value="__ACCENT__"/>
                <Setter TargetName="bd" Property="BorderThickness" Value="2"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="InputPassword" TargetType="PasswordBox">
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Foreground" Value="#111827"/>
      <Setter Property="Padding" Value="10,9"/>
      <Setter Property="Background" Value="#FFFFFF"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="PasswordBox">
            <Border x:Name="bd" Background="{TemplateBinding Background}" BorderBrush="#D1D5DB"
                    BorderThickness="1" CornerRadius="6">
              <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="bd" Property="BorderBrush" Value="__ACCENT__"/>
                <Setter TargetName="bd" Property="BorderThickness" Value="2"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="Heading" TargetType="TextBlock">
      <Setter Property="FontSize" Value="20"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Foreground" Value="#111827"/>
      <Setter Property="TextWrapping" Value="Wrap"/>
    </Style>
    <Style x:Key="Body" TargetType="TextBlock">
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Foreground" Value="#4B5563"/>
      <Setter Property="TextWrapping" Value="Wrap"/>
      <Setter Property="LineHeight" Value="20"/>
    </Style>
    <Style x:Key="FieldLabel" TargetType="TextBlock">
      <Setter Property="FontSize" Value="12.5"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Foreground" Value="#374151"/>
      <Setter Property="Margin" Value="0,0,0,6"/>
    </Style>
    <Style x:Key="StepNum" TargetType="Border">
      <Setter Property="Width" Value="22"/>
      <Setter Property="Height" Value="22"/>
      <Setter Property="CornerRadius" Value="11"/>
      <Setter Property="Background" Value="__ACCENT_LIGHT__"/>
      <Setter Property="Margin" Value="0,0,10,0"/>
      <Setter Property="VerticalAlignment" Value="Top"/>
    </Style>
    <Style x:Key="StepNumText" TargetType="TextBlock">
      <Setter Property="FontSize" Value="12"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Foreground" Value="__ACCENT_DARK__"/>
      <Setter Property="HorizontalAlignment" Value="Center"/>
      <Setter Property="VerticalAlignment" Value="Center"/>
    </Style>
    <Style x:Key="StepText" TargetType="TextBlock" BasedOn="{StaticResource Body}">
      <Setter Property="Foreground" Value="#374151"/>
      <Setter Property="VerticalAlignment" Value="Center"/>
    </Style>
  </Window.Resources>

  <Border x:Name="RootCard" Background="#FFFFFF" CornerRadius="12" Margin="20">
    <Border.Effect>
      <DropShadowEffect x:Name="RootShadow" Color="#000000" Opacity="0.10" BlurRadius="24" ShadowDepth="4" Direction="270"/>
    </Border.Effect>
    <StackPanel Margin="36,28,36,24">

      <!-- ============ Header (always visible) ============ -->
      <Grid Margin="0,0,0,20">
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="Auto"/>
          <ColumnDefinition Width="Auto"/>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="Auto"/>
        </Grid.ColumnDefinitions>
        <Border x:Name="BrandGlyphBox" Grid.Column="0" Width="34" Height="34" CornerRadius="8"
                Background="__ACCENT_LIGHT__" VerticalAlignment="Center">
          <TextBlock FontFamily="Segoe MDL2 Assets" Text="&#xE72E;" FontSize="16"
                     Foreground="__ACCENT_DARK__" HorizontalAlignment="Center" VerticalAlignment="Center"/>
        </Border>
        <Image x:Name="ImgLogo" Grid.Column="0" Height="34" Visibility="Collapsed"
               VerticalAlignment="Center" Stretch="Uniform"/>
        <TextBlock Grid.Column="1" Text="JumpCloud" FontSize="15" FontWeight="SemiBold"
                   Foreground="#111827" VerticalAlignment="Center" Margin="10,0,0,0"/>
        <TextBlock x:Name="TxtHeaderCompany" Grid.Column="3" FontSize="11.5" Foreground="#9CA3AF"
                   VerticalAlignment="Center"/>
      </Grid>

      <Grid>
        <!-- ============ WELCOME ============ -->
        <StackPanel x:Name="PanelWelcome" Visibility="Visible">
          <StackPanel.RenderTransform><TranslateTransform Y="0"/></StackPanel.RenderTransform>
          <Border Width="64" Height="64" CornerRadius="32" Background="__ACCENT_LIGHT__"
                  HorizontalAlignment="Left" Margin="0,4,0,18">
            <TextBlock FontFamily="Segoe MDL2 Assets" Text="&#xE71B;" FontSize="28"
                       Foreground="__ACCENT_DARK__" HorizontalAlignment="Center" VerticalAlignment="Center"/>
          </Border>
          <TextBlock x:Name="HdrWelcome" Style="{StaticResource Heading}" Text="Welcome to JumpCloud"
                     AutomationProperties.AutomationId="HdrWelcome"/>
          <TextBlock x:Name="TxtWelcomeBody" Style="{StaticResource Body}" Margin="0,10,0,4"/>
          <TextBlock x:Name="TxtWelcomeNote" Style="{StaticResource Body}" Margin="0,6,0,22"
                     Text="Once linked, your JumpCloud password becomes your Windows sign-in password."/>
          <Button x:Name="BtnLink" Style="{StaticResource PrimaryButton}" Content="Link My JumpCloud Account"
                  TabIndex="1" AutomationProperties.AutomationId="BtnLink"/>
          <Button x:Name="BtnDefer" Style="{StaticResource SecondaryButton}" Content="Remind Me Later"
                  Margin="0,10,0,0" TabIndex="2" AutomationProperties.AutomationId="BtnDefer"/>
          <TextBlock x:Name="TxtDeferNote" FontSize="11.5" Foreground="#9CA3AF" TextWrapping="Wrap"
                     TextAlignment="Center" Margin="0,10,0,0"/>
        </StackPanel>

        <!-- ============ ACCOUNT ENTRY ============ -->
        <StackPanel x:Name="PanelAccount" Visibility="Collapsed">
          <StackPanel.RenderTransform><TranslateTransform Y="0"/></StackPanel.RenderTransform>
          <Button x:Name="BtnBack" Style="{StaticResource LinkButton}" HorizontalAlignment="Left"
                  Margin="-4,0,0,12" TabIndex="14" AutomationProperties.AutomationId="BtnBack">
            <StackPanel Orientation="Horizontal">
              <TextBlock FontFamily="Segoe MDL2 Assets" Text="&#xE72B;" FontSize="12" VerticalAlignment="Center"/>
              <TextBlock Text="Back" Margin="6,0,0,0" VerticalAlignment="Center"/>
            </StackPanel>
          </Button>
          <TextBlock x:Name="HdrAccount" Style="{StaticResource Heading}" Text="Verify your JumpCloud account"
                     AutomationProperties.AutomationId="HdrAccount"/>
          <TextBlock Style="{StaticResource Body}" Margin="0,8,0,20"
                     Text="Enter your JumpCloud credentials to securely link your account with this device."/>

          <TextBlock Style="{StaticResource FieldLabel}" Text="Work email"/>
          <TextBox x:Name="TxtEmail" Style="{StaticResource InputText}" TabIndex="10"
                   AutomationProperties.Name="Work email" AutomationProperties.AutomationId="TxtEmail"/>

          <TextBlock Style="{StaticResource FieldLabel}" Text="JumpCloud password" Margin="0,14,0,6"/>
          <Grid>
            <Grid.ColumnDefinitions>
              <ColumnDefinition Width="*"/>
              <ColumnDefinition Width="Auto"/>
            </Grid.ColumnDefinitions>
            <PasswordBox x:Name="PwdPassword" Grid.Column="0" Style="{StaticResource InputPassword}" TabIndex="11"
                         AutomationProperties.Name="JumpCloud password" AutomationProperties.AutomationId="PwdPassword"/>
            <TextBox x:Name="TxtPasswordReveal" Grid.Column="0" Style="{StaticResource InputText}"
                     Visibility="Collapsed" TabIndex="11"
                     AutomationProperties.Name="JumpCloud password (visible)"
                     AutomationProperties.AutomationId="TxtPasswordReveal"/>
            <Button x:Name="BtnTogglePwd" Grid.Column="1" Style="{StaticResource LinkButton}" Content="Show"
                    Margin="8,0,0,0" VerticalAlignment="Center" TabIndex="12"
                    AutomationProperties.Name="Show or hide password" AutomationProperties.AutomationId="BtnTogglePwd"/>
          </Grid>

          <TextBlock x:Name="TxtValidation" FontSize="12.5" Foreground="#B42318" TextWrapping="Wrap"
                     Margin="0,10,0,0" Visibility="Collapsed"
                     AutomationProperties.LiveSetting="Assertive" AutomationProperties.AutomationId="TxtValidation"/>

          <Button x:Name="BtnVerify" Style="{StaticResource PrimaryButton}" Content="Verify &amp; Link Account"
                  Margin="0,20,0,0" TabIndex="13" AutomationProperties.AutomationId="BtnVerify"/>
        </StackPanel>

        <!-- ============ PROGRESS ============ -->
        <StackPanel x:Name="PanelProgress" Visibility="Collapsed">
          <StackPanel.RenderTransform><TranslateTransform Y="0"/></StackPanel.RenderTransform>
          <Grid Width="44" Height="44" HorizontalAlignment="Center" Margin="0,28,0,18">
            <Ellipse Stroke="#E5E7EB" StrokeThickness="4"/>
            <!-- Spinner rotation is driven from code (Start/Stop-Spinner) so
                 it only animates while this panel is visible - a perpetual
                 XAML animation would re-render continuously under software
                 rendering (RDP) and make the whole window feel frozen. -->
            <Path Stroke="__ACCENT__" StrokeThickness="4" StrokeStartLineCap="Round" StrokeEndLineCap="Round"
                  Data="M 22,2 A 20,20 0 0 1 42,22" RenderTransformOrigin="0.5,0.5">
              <Path.RenderTransform><RotateTransform x:Name="SpinnerRotate" Angle="0"/></Path.RenderTransform>
            </Path>
          </Grid>
          <TextBlock x:Name="TxtProgress" FontSize="15" FontWeight="SemiBold" Foreground="#111827"
                     TextAlignment="Center" TextWrapping="Wrap" Text="Verifying your account..."
                     AutomationProperties.LiveSetting="Polite" AutomationProperties.AutomationId="TxtProgress"/>
          <TextBlock Style="{StaticResource Body}" TextAlignment="Center" Margin="0,8,0,28"
                     Text="This usually takes less than a minute. Please keep this window open."/>
        </StackPanel>

        <!-- ============ AUTH FAILED ============ -->
        <StackPanel x:Name="PanelAuthFailed" Visibility="Collapsed">
          <StackPanel.RenderTransform><TranslateTransform Y="0"/></StackPanel.RenderTransform>
          <Border Width="56" Height="56" CornerRadius="28" Background="#FEF3C7"
                  HorizontalAlignment="Left" Margin="0,4,0,16">
            <TextBlock FontFamily="Segoe MDL2 Assets" Text="&#xE7BA;" FontSize="24"
                       Foreground="#B45309" HorizontalAlignment="Center" VerticalAlignment="Center"/>
          </Border>
          <TextBlock x:Name="HdrAuthFailed" Style="{StaticResource Heading}"
                     Text="We couldn't verify your account" AutomationProperties.AutomationId="HdrAuthFailed"/>
          <TextBlock x:Name="TxtAuthFailedMsg" Style="{StaticResource Body}" Margin="0,10,0,22"
                     AutomationProperties.LiveSetting="Assertive"/>
          <Button x:Name="BtnTryAgainAuth" Style="{StaticResource PrimaryButton}" Content="Try Again"
                  TabIndex="1" AutomationProperties.AutomationId="BtnTryAgainAuth"/>
          <Button x:Name="BtnDeferAuth" Style="{StaticResource SecondaryButton}" Content="Remind Me Later"
                  Margin="0,10,0,0" TabIndex="2" AutomationProperties.AutomationId="BtnDeferAuth"/>
        </StackPanel>

        <!-- ============ BIND FAILED / SYSTEM ERROR ============ -->
        <StackPanel x:Name="PanelBindFailed" Visibility="Collapsed">
          <StackPanel.RenderTransform><TranslateTransform Y="0"/></StackPanel.RenderTransform>
          <Border Width="56" Height="56" CornerRadius="28" Background="#FEE2E2"
                  HorizontalAlignment="Left" Margin="0,4,0,16">
            <TextBlock FontFamily="Segoe MDL2 Assets" Text="&#xE783;" FontSize="24"
                       Foreground="#B42318" HorizontalAlignment="Center" VerticalAlignment="Center"/>
          </Border>
          <TextBlock x:Name="HdrBindFailed" Style="{StaticResource Heading}"
                     Text="We couldn't link your account" AutomationProperties.AutomationId="HdrBindFailed"/>
          <TextBlock x:Name="TxtBindFailedMsg" Style="{StaticResource Body}" Margin="0,10,0,10"
                     AutomationProperties.LiveSetting="Assertive"/>
          <TextBlock x:Name="TxtRefCode" FontSize="11.5" Foreground="#9CA3AF" Margin="0,0,0,20"
                     AutomationProperties.AutomationId="TxtRefCode"/>
          <Button x:Name="BtnRetryBind" Style="{StaticResource PrimaryButton}" Content="Try Again"
                  TabIndex="1" AutomationProperties.AutomationId="BtnRetryBind"/>
          <Button x:Name="BtnCloseBindFailed" Style="{StaticResource SecondaryButton}" Content="Close"
                  Margin="0,10,0,0" TabIndex="2" AutomationProperties.AutomationId="BtnCloseBindFailed"/>
        </StackPanel>

        <!-- ============ SUCCESS ============ -->
        <StackPanel x:Name="PanelSuccess" Visibility="Collapsed">
          <StackPanel.RenderTransform><TranslateTransform Y="0"/></StackPanel.RenderTransform>
          <Grid Width="64" Height="64" HorizontalAlignment="Left" Margin="0,4,0,16">
            <Ellipse Fill="#DCFCE7"/>
            <Ellipse Fill="#16A34A" Width="48" Height="48"/>
            <Path Stroke="#FFFFFF" StrokeThickness="4" StrokeStartLineCap="Round" StrokeEndLineCap="Round"
                  StrokeLineJoin="Round" Data="M 24,33 L 30,39 L 41,26"/>
          </Grid>
          <TextBlock x:Name="HdrSuccess" Style="{StaticResource Heading}"
                     Text="Your JumpCloud account is linked" AutomationProperties.AutomationId="HdrSuccess"/>
          <TextBlock Style="{StaticResource Body}" Margin="0,8,0,18"
                     Text="Your JumpCloud account has been successfully linked to this device."/>

          <Border Background="#F9FAFB" BorderBrush="#E5E7EB" BorderThickness="1" CornerRadius="8" Padding="16">
            <StackPanel>
              <TextBlock Text="What happens next" FontSize="13" FontWeight="SemiBold"
                         Foreground="#111827" Margin="0,0,0,10"/>
              <Grid Margin="0,0,0,8">
                <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                <Border Style="{StaticResource StepNum}"><TextBlock Style="{StaticResource StepNumText}" Text="1"/></Border>
                <TextBlock Grid.Column="1" Style="{StaticResource StepText}" Text="Sign out of Windows."/>
              </Grid>
              <Grid Margin="0,0,0,8">
                <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                <Border Style="{StaticResource StepNum}"><TextBlock Style="{StaticResource StepNumText}" Text="2"/></Border>
                <TextBlock Grid.Column="1" Style="{StaticResource StepText}" Text="On the next sign-in, you may see two password fields."/>
              </Grid>
              <Grid Margin="0,0,0,8">
                <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                <Border Style="{StaticResource StepNum}"><TextBlock Style="{StaticResource StepNumText}" Text="3"/></Border>
                <TextBlock Grid.Column="1" Style="{StaticResource StepText}" Text="In the first password field, enter your current Windows password."/>
              </Grid>
              <Grid Margin="0,0,0,8">
                <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                <Border Style="{StaticResource StepNum}"><TextBlock Style="{StaticResource StepNumText}" Text="4"/></Border>
                <TextBlock Grid.Column="1" Style="{StaticResource StepText}" Text="In the second password field, enter your JumpCloud password."/>
              </Grid>
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                <Border Style="{StaticResource StepNum}"><TextBlock Style="{StaticResource StepNumText}" Text="5"/></Border>
                <TextBlock Grid.Column="1" Style="{StaticResource StepText}" Text="Complete the sign-in."/>
              </Grid>
            </StackPanel>
          </Border>

          <TextBlock Style="{StaticResource Body}" Margin="0,14,0,20"
                     Text="After the first successful sign-in, your JumpCloud password will be synchronized with Windows. Going forward, use your JumpCloud password to sign in to this device."/>

          <Button x:Name="BtnSignOutNow" Style="{StaticResource PrimaryButton}" Content="Sign Out Now"
                  TabIndex="1" AutomationProperties.AutomationId="BtnSignOutNow"/>
          <Button x:Name="BtnSignOutLater" Style="{StaticResource SecondaryButton}" Content="I'll Sign Out Later"
                  Margin="0,10,0,0" TabIndex="2" AutomationProperties.AutomationId="BtnSignOutLater"/>
        </StackPanel>

        <!-- ============ BLOCKED ============ -->
        <StackPanel x:Name="PanelBlocked" Visibility="Collapsed">
          <StackPanel.RenderTransform><TranslateTransform Y="0"/></StackPanel.RenderTransform>
          <Border Width="56" Height="56" CornerRadius="28" Background="#E5E7EB"
                  HorizontalAlignment="Left" Margin="0,4,0,16">
            <TextBlock FontFamily="Segoe MDL2 Assets" Text="&#xE946;" FontSize="24"
                       Foreground="#374151" HorizontalAlignment="Center" VerticalAlignment="Center"/>
          </Border>
          <TextBlock x:Name="HdrBlocked" Style="{StaticResource Heading}"
                     Text="This device can't be linked right now" AutomationProperties.AutomationId="HdrBlocked"/>
          <TextBlock x:Name="TxtBlockedMsg" Style="{StaticResource Body}" Margin="0,10,0,10"/>
          <TextBlock x:Name="TxtBlockedRef" FontSize="11.5" Foreground="#9CA3AF" Margin="0,0,0,20"/>
          <Button x:Name="BtnCloseBlocked" Style="{StaticResource SecondaryButton}" Content="Close"
                  TabIndex="1" AutomationProperties.AutomationId="BtnCloseBlocked"/>
        </StackPanel>
      </Grid>

      <!-- ============ Footer ============ -->
      <TextBlock x:Name="TxtFooter" FontSize="11" Foreground="#9CA3AF" TextAlignment="Center"
                 TextWrapping="Wrap" Margin="0,22,0,0"/>
    </StackPanel>
  </Border>
</Window>
'@

$xaml = $xaml.Replace('__ACCENT_DARKER__', $AccentDarker).
              Replace('__ACCENT_DARK__', $AccentDark).
              Replace('__ACCENT_LIGHT__', $AccentLight).
              Replace('__ACCENT__', $AccentHex)

try {
    $window = [Windows.Markup.XamlReader]::Parse($xaml)
}
catch {
    Write-JCLog "XAML parse failed: $($_.Exception.Message)" 'ERROR'
    exit 1
}

# --- Control lookup ---------------------------------------------------
$ui = @{}
$controlNames = @(
    'RootCard', 'RootShadow', 'SpinnerRotate',
    'BrandGlyphBox', 'ImgLogo', 'TxtHeaderCompany', 'TxtFooter',
    'PanelWelcome', 'HdrWelcome', 'TxtWelcomeBody', 'TxtWelcomeNote', 'BtnLink', 'BtnDefer', 'TxtDeferNote',
    'PanelAccount', 'BtnBack', 'TxtEmail', 'PwdPassword', 'TxtPasswordReveal', 'BtnTogglePwd', 'TxtValidation', 'BtnVerify',
    'PanelProgress', 'TxtProgress',
    'PanelAuthFailed', 'TxtAuthFailedMsg', 'BtnTryAgainAuth', 'BtnDeferAuth',
    'PanelBindFailed', 'HdrBindFailed', 'TxtBindFailedMsg', 'TxtRefCode', 'BtnRetryBind', 'BtnCloseBindFailed',
    'PanelSuccess', 'BtnSignOutNow', 'BtnSignOutLater',
    'PanelBlocked', 'TxtBlockedMsg', 'TxtBlockedRef', 'BtnCloseBlocked'
)
foreach ($name in $controlNames) { $ui[$name] = $window.FindName($name) }

# A blurred DropShadowEffect is re-rasterized in software on RDP/no-GPU
# machines; drop it there and give the card a flat border instead.
if ($script:SoftwareRender -and $ui.RootCard) {
    $ui.RootCard.Effect = $null
    $ui.RootCard.BorderThickness = New-Object System.Windows.Thickness(1)
    $ui.RootCard.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString('#E5E7EB'))
}

$panels = @{
    WELCOME     = 'PanelWelcome'
    ACCOUNT     = 'PanelAccount'
    PROGRESS    = 'PanelProgress'
    AUTH_FAILED = 'PanelAuthFailed'
    BIND_FAILED = 'PanelBindFailed'
    SUCCESS     = 'PanelSuccess'
    BLOCKED     = 'PanelBlocked'
}
$primaryButtons = @{
    WELCOME     = 'BtnLink'
    ACCOUNT     = 'BtnVerify'
    AUTH_FAILED = 'BtnTryAgainAuth'
    BIND_FAILED = 'BtnRetryBind'
    SUCCESS     = 'BtnSignOutNow'
    BLOCKED     = 'BtnCloseBlocked'
}

# --- Dynamic copy -----------------------------------------------------
$ui.TxtHeaderCompany.Text = $CompanyName
$ui.TxtFooter.Text = "Managed by $CompanyName. Questions? Contact $SupportContact."
$ui.TxtWelcomeBody.Text = "$CompanyName uses JumpCloud to securely manage identity and access to company resources. To provide a seamless sign-in experience, link your JumpCloud account with this device."

if ($DeferMinutes -lt 90) {
    $deferPhrase = "about $DeferMinutes minutes"
}
else {
    $deferHours = [Math]::Round($DeferMinutes / 60.0, 1)
    if ($deferHours -eq [Math]::Floor($deferHours)) { $deferHours = [int]$deferHours }
    $deferPhrase = "about $deferHours hours"
}
$ui.TxtDeferNote.Text = "Not a good time? You'll be reminded again in $deferPhrase."

if (-not $AllowDefer) {
    $ui.BtnDefer.Visibility = 'Collapsed'
    $ui.TxtDeferNote.Text = 'Linking is required and can no longer be postponed.'
    $ui.BtnDeferAuth.Visibility = 'Collapsed'
}

# Official logo only - never a recreated one.
try {
    $logoPath = [string]$cfg.Ui.LogoPath
    if (-not [string]::IsNullOrWhiteSpace($logoPath) -and (Test-Path $logoPath)) {
        $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
        $bmp.BeginInit()
        $bmp.UriSource = New-Object System.Uri($logoPath, [System.UriKind]::Absolute)
        $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bmp.EndInit()
        $ui.ImgLogo.Source = $bmp
        $ui.ImgLogo.Visibility = 'Visible'
        $ui.BrandGlyphBox.Visibility = 'Collapsed'
    }
} catch { Write-JCLog "Logo load failed: $($_.Exception.Message)" 'WARN' }

# --- App state --------------------------------------------------------
$script:Screen          = 'WELCOME'
$script:Phase           = 'IDLE'    # IDLE | RESOLVING | VERIFYING | LINKING | DONE
$script:ReqSeq          = 0
$script:LastStatusSeq   = 0
$script:Email           = ''
$script:Username        = ''
$script:PendingPassword = $null     # SecureString, disposed after each attempt
$script:AsyncPs         = $null
$script:AsyncHandle     = $null
$script:StateDeadline   = [datetime]::MaxValue
$script:RetryMode       = 'binding' # binding | account | none
$script:AppClose        = $false
$script:TickCount       = 0

function Send-Action {
    param([string]$Action, [hashtable]$Extra = @{})
    $script:ReqSeq++
    $msg = @{ seq = $script:ReqSeq; action = $Action }
    foreach ($k in $Extra.Keys) { $msg[$k] = $Extra[$k] }
    [void](Write-IpcMessage -Path $ReqPath -Message $msg)
    Write-JCLog "Sent action '$Action' (seq $($script:ReqSeq))"
}

$script:SpinnerAnim = $null
function Start-Spinner {
    if ($script:SpinnerAnim -or -not $ui.SpinnerRotate) { return }
    # Under software rendering a perpetual rotation still costs render
    # cycles, but only for the few seconds this panel is up. Keep it.
    $dur = New-Object System.Windows.Duration([TimeSpan]::FromSeconds(1))
    $anim = New-Object System.Windows.Media.Animation.DoubleAnimation(0.0, 360.0, $dur)
    $anim.RepeatBehavior = [System.Windows.Media.Animation.RepeatBehavior]::Forever
    $ui.SpinnerRotate.BeginAnimation([System.Windows.Media.RotateTransform]::AngleProperty, $anim)
    $script:SpinnerAnim = $anim
}
function Stop-Spinner {
    if (-not $ui.SpinnerRotate) { return }
    $ui.SpinnerRotate.BeginAnimation([System.Windows.Media.RotateTransform]::AngleProperty, $null)
    $script:SpinnerAnim = $null
}

function Show-Screen {
    param([string]$Name)
    foreach ($key in $panels.Keys) {
        $ui[$panels[$key]].Visibility = 'Collapsed'
        if ($primaryButtons.ContainsKey($key)) { $ui[$primaryButtons[$key]].IsDefault = $false }
    }
    if ($Name -eq 'PROGRESS') { Start-Spinner } else { Stop-Spinner }
    $panel = $ui[$panels[$Name]]
    $panel.Opacity = 0
    $panel.Visibility = 'Visible'

    # Entry transitions are cosmetic; skip them under software rendering so
    # the first paint is immediate and never looks like a stall.
    if (-not $script:SoftwareRender) {
        $duration = New-Object System.Windows.Duration([TimeSpan]::FromMilliseconds(240))
        $fade = New-Object System.Windows.Media.Animation.DoubleAnimation(0.0, 1.0, $duration)
        $ease = New-Object System.Windows.Media.Animation.CubicEase
        $ease.EasingMode = [System.Windows.Media.Animation.EasingMode]::EaseOut
        $slide = New-Object System.Windows.Media.Animation.DoubleAnimation(12.0, 0.0, $duration)
        $slide.EasingFunction = $ease
        $panel.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $fade)
        $panel.RenderTransform.BeginAnimation([System.Windows.Media.TranslateTransform]::YProperty, $slide)
    }
    else {
        $panel.Opacity = 1
    }

    if ($primaryButtons.ContainsKey($Name)) { $ui[$primaryButtons[$Name]].IsDefault = $true }
    $script:Screen = $Name
    Write-JCLog "Screen -> $Name"

    # Focus after layout settles.
    $window.Dispatcher.BeginInvoke([System.Windows.Threading.DispatcherPriority]::Input, [action] {
        switch ($script:Screen) {
            'ACCOUNT' {
                if ([string]::IsNullOrWhiteSpace($ui.TxtEmail.Text)) { [void]$ui.TxtEmail.Focus() }
                elseif ($ui.TxtPasswordReveal.Visibility -eq 'Visible') { [void]$ui.TxtPasswordReveal.Focus() }
                else { [void]$ui.PwdPassword.Focus() }
            }
            default {
                if ($primaryButtons.ContainsKey($script:Screen)) {
                    $btn = $ui[$primaryButtons[$script:Screen]]
                    if ($btn.Visibility -eq 'Visible') { [void]$btn.Focus() }
                }
            }
        }
    }) | Out-Null
}

function Set-Progress {
    param([string]$Text)
    $ui.TxtProgress.Text = $Text
}

function Clear-PendingPassword {
    if ($script:PendingPassword) {
        try { $script:PendingPassword.Dispose() } catch { }
        $script:PendingPassword = $null
    }
}

function Clear-PasswordFields {
    $ui.PwdPassword.Clear()
    $ui.TxtPasswordReveal.Clear()
    if ($ui.TxtPasswordReveal.Visibility -eq 'Visible') {
        $ui.TxtPasswordReveal.Visibility = 'Collapsed'
        $ui.PwdPassword.Visibility = 'Visible'
        $ui.BtnTogglePwd.Content = 'Show'
    }
}

function Show-Validation {
    param([string]$Text)
    $ui.TxtValidation.Text = $Text
    $ui.TxtValidation.Visibility = 'Visible'
}

function Hide-Validation {
    $ui.TxtValidation.Visibility = 'Collapsed'
}

function Show-AuthFailed {
    param([string]$Message)
    Clear-PendingPassword
    $ui.TxtAuthFailedMsg.Text = $Message
    $script:Phase = 'IDLE'
    Show-Screen 'AUTH_FAILED'
}

function Show-BindFailed {
    param([string]$Heading, [string]$Message, [string]$RefCode, [string]$RetryMode = 'binding')
    Clear-PendingPassword
    $ui.HdrBindFailed.Text = $Heading
    $ui.TxtBindFailedMsg.Text = $Message
    if ([string]::IsNullOrEmpty($RefCode)) {
        $ui.TxtRefCode.Text = ''
        $ui.TxtRefCode.Visibility = 'Collapsed'
    }
    else {
        $ui.TxtRefCode.Text = "Support reference: $RefCode"
        $ui.TxtRefCode.Visibility = 'Visible'
    }
    $script:RetryMode = $RetryMode
    if ($RetryMode -eq 'none') { $ui.BtnRetryBind.Visibility = 'Collapsed' }
    else { $ui.BtnRetryBind.Visibility = 'Visible' }
    $script:Phase = 'IDLE'
    Show-Screen 'BIND_FAILED'
}

function Get-EnteredPassword {
    # Returns a SecureString (caller owns disposal) or $null when empty.
    if ($ui.TxtPasswordReveal.Visibility -eq 'Visible') {
        $plain = $ui.TxtPasswordReveal.Text
        if ([string]::IsNullOrEmpty($plain)) { return $null }
        return (ConvertTo-SecureString -String $plain -AsPlainText -Force)
    }
    # SecurePassword already returns a caller-owned copy.
    $sec = $ui.PwdPassword.SecurePassword
    if ($sec.Length -lt 1) {
        $sec.Dispose()
        return $null
    }
    return $sec
}

function Start-LdapVerification {
    $authModulePath = Join-Path $ModulesDir 'JCEnrollment.Auth.psm1'
    $ldapJson = $cfg.Ldap | ConvertTo-Json -Depth 6
    $ps = [powershell]::Create()
    [void]$ps.AddScript({
        param($AuthModulePath, $LdapJson, $Username, $Email, $SecurePassword)
        try {
            Import-Module $AuthModulePath -Force
            $ldapCfg = $LdapJson | ConvertFrom-Json
            Test-JCLdapCredential -LdapConfig $ldapCfg -Username $Username -Email $Email -Password $SecurePassword
        }
        catch {
            [pscustomobject]@{ Result = 'Unavailable'; Detail = "worker: $($_.Exception.GetType().Name)" }
        }
    })
    [void]$ps.AddArgument($authModulePath)
    [void]$ps.AddArgument($ldapJson)
    [void]$ps.AddArgument($script:Username)
    [void]$ps.AddArgument($script:Email)
    [void]$ps.AddArgument($script:PendingPassword)
    $script:AsyncPs = $ps
    $script:AsyncHandle = $ps.BeginInvoke()
    $ldapTimeout = 20
    try { if ([int]$cfg.Ldap.TimeoutSeconds -gt 0) { $ldapTimeout = [int]$cfg.Ldap.TimeoutSeconds + 10 } } catch { }
    $script:StateDeadline = (Get-Date).AddSeconds($ldapTimeout + 15)
    $script:Phase = 'VERIFYING'
    Write-JCLog 'LDAP verification started'
}

function Start-Verification {
    if ($script:Phase -ne 'IDLE') { return }
    Hide-Validation

    $email = $ui.TxtEmail.Text.Trim().ToLower()
    if ([string]::IsNullOrWhiteSpace($email)) {
        Show-Validation 'Enter your work email address.'
        [void]$ui.TxtEmail.Focus()
        return
    }
    if ($email -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') {
        Show-Validation "That doesn't look like a valid email address. Check it and try again."
        [void]$ui.TxtEmail.Focus()
        return
    }
    $secure = Get-EnteredPassword
    if ($null -eq $secure) {
        Show-Validation 'Enter your JumpCloud password.'
        if ($ui.TxtPasswordReveal.Visibility -eq 'Visible') { [void]$ui.TxtPasswordReveal.Focus() }
        else { [void]$ui.PwdPassword.Focus() }
        return
    }

    Clear-PendingPassword
    $script:PendingPassword = $secure
    $script:Email = $email
    Write-JCLog "Verification requested for $(Get-MaskedEmail $email)"

    Set-Progress 'Verifying your account...'
    Show-Screen 'PROGRESS'
    $script:Phase = 'RESOLVING'
    $script:StateDeadline = (Get-Date).AddSeconds($ResolveTimeoutSec)
    Send-Action 'resolve_user' @{ email = $email }
}

function Close-App {
    $script:AppClose = $true
    $window.Close()
}

function Invoke-Defer {
    Write-JCLog 'User selected Remind Me Later'
    Send-Action 'defer'
    Close-App
}

# --- Timer: heartbeats, async results, orchestrator status ------------
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(250)
$timer.Add_Tick({
    try {
        $script:TickCount++
        if (($script:TickCount % 8) -eq 0) { Write-Heartbeat -Path $HbUiPath }

        switch ($script:Phase) {
            'RESOLVING' {
                $status = Read-IpcMessage -Path $StatusPath -AfterSeq $script:LastStatusSeq
                if ($status) {
                    $script:LastStatusSeq = [long]$status.seq
                    if ($status.state -eq 'USER_RESOLVED') {
                        if ($status.ok -eq $true) {
                            $script:Username = [string]$status.username
                            Write-JCLog 'User resolved; starting credential verification'
                            Start-LdapVerification
                        }
                        else {
                            # Same message as a wrong password - no account enumeration.
                            Write-JCLog 'User resolution returned no match' 'WARN'
                            Show-AuthFailed "The email address or password you entered couldn't be verified. Check your credentials and try again."
                        }
                    }
                }
                elseif ((Get-Date) -gt $script:StateDeadline) {
                    Write-JCLog 'Timed out waiting for user resolution' 'ERROR'
                    Show-BindFailed -Heading 'Something went wrong' `
                        -Message "We couldn't complete the request. Please try again in a moment, or contact $SupportContact if the problem continues." `
                        -RefCode 'RESOLVE_TIMEOUT' -RetryMode 'account'
                }
            }
            'VERIFYING' {
                $finished = $false
                if ($script:AsyncHandle -and $script:AsyncHandle.IsCompleted) { $finished = $true }
                elseif ((Get-Date) -gt $script:StateDeadline) { $finished = $true }

                if ($finished) {
                    $result = $null
                    try {
                        if ($script:AsyncHandle.IsCompleted) {
                            $out = $script:AsyncPs.EndInvoke($script:AsyncHandle)
                            if ($out.Count -gt 0) { $result = $out[$out.Count - 1] }
                        }
                        else {
                            $script:AsyncPs.Stop()
                        }
                    }
                    catch { Write-JCLog "LDAP worker error: $($_.Exception.GetType().Name)" 'ERROR' }
                    finally {
                        if ($script:AsyncPs) { try { $script:AsyncPs.Dispose() } catch { } }
                        $script:AsyncPs = $null
                        $script:AsyncHandle = $null
                    }
                    if ($null -eq $result) {
                        $result = [pscustomobject]@{ Result = 'Timeout'; Detail = 'worker did not finish' }
                    }
                    Write-JCLog "Authentication result: $($result.Result)"

                    switch ($result.Result) {
                        'Success' {
                            Clear-PendingPassword
                            Clear-PasswordFields
                            Set-Progress 'Linking your account to this device...'
                            $script:Phase = 'LINKING'
                            $script:StateDeadline = (Get-Date).AddSeconds($BindingTimeoutSec)
                            Send-Action 'auth_success' @{ email = $script:Email }
                        }
                        'InvalidCredentials' {
                            Clear-PasswordFields
                            Show-AuthFailed "The email address or password you entered couldn't be verified. Check your credentials and try again."
                        }
                        'Timeout' {
                            Show-AuthFailed "Verification is taking longer than expected. Check your network connection and try again."
                        }
                        'ConfigError' {
                            Show-BindFailed -Heading 'Something went wrong' `
                                -Message "Account verification isn't set up correctly on this device. Please contact $SupportContact." `
                                -RefCode 'AUTH_CONFIG' -RetryMode 'none'
                        }
                        default {
                            Show-AuthFailed "We couldn't reach the verification service. Check your network connection and try again."
                        }
                    }
                }
            }
            'LINKING' {
                $status = Read-IpcMessage -Path $StatusPath -AfterSeq $script:LastStatusSeq
                if ($status) {
                    $script:LastStatusSeq = [long]$status.seq
                    switch ($status.state) {
                        'LINKING' { Set-Progress 'Linking your account to this device...' }
                        'SUCCESS' {
                            $script:Phase = 'DONE'
                            Show-Screen 'SUCCESS'
                        }
                        'BINDING_FAILED' {
                            $ref = ''
                            try { $ref = [string]$status.category } catch { }
                            Show-BindFailed -Heading "We couldn't link your account" `
                                -Message "Your account was verified, but we couldn't finish linking it to this device. Please try again, or contact $SupportContact if the problem continues." `
                                -RefCode $ref -RetryMode 'binding'
                        }
                    }
                }
                elseif ((Get-Date) -gt $script:StateDeadline -or (Get-HeartbeatAgeSeconds -Path $HbSysPath) -gt 45) {
                    Write-JCLog 'Linking timed out or orchestrator stopped responding' 'ERROR'
                    Show-BindFailed -Heading "We couldn't link your account" `
                        -Message "Your account was verified, but linking did not finish in time. Please try again, or contact $SupportContact if the problem continues." `
                        -RefCode 'LINK_TIMEOUT' -RetryMode 'binding'
                }
            }
        }
    }
    catch {
        Write-JCLog "Tick error: $($_.Exception.Message)" 'ERROR'
    }
})

# --- Event wiring -----------------------------------------------------
$ui.BtnLink.Add_Click({ Show-Screen 'ACCOUNT' })
$ui.BtnDefer.Add_Click({ Invoke-Defer })
$ui.BtnDeferAuth.Add_Click({ Invoke-Defer })
$ui.BtnBack.Add_Click({
    Hide-Validation
    Show-Screen 'WELCOME'
})
$ui.BtnVerify.Add_Click({ Start-Verification })
$ui.BtnTryAgainAuth.Add_Click({
    Hide-Validation
    Show-Screen 'ACCOUNT'
})
$ui.BtnRetryBind.Add_Click({
    if ($script:RetryMode -eq 'account') {
        Hide-Validation
        Show-Screen 'ACCOUNT'
        return
    }
    Set-Progress 'Linking your account to this device...'
    Show-Screen 'PROGRESS'
    $script:Phase = 'LINKING'
    $script:StateDeadline = (Get-Date).AddSeconds($BindingTimeoutSec)
    Send-Action 'retry_binding'
})
$ui.BtnCloseBindFailed.Add_Click({
    Send-Action 'closed'
    Close-App
})
$ui.BtnCloseBlocked.Add_Click({
    Send-Action 'closed'
    Close-App
})
$ui.BtnSignOutNow.Add_Click({
    Write-JCLog 'User selected Sign Out Now'
    Send-Action 'sign_out_now'
    if ($SuppressSignOut) {
        Write-JCLog 'Test mode: sign-out suppressed' 'WARN'
    }
    else {
        # Standard, non-forced Windows sign-out of the current session.
        Start-Process -FilePath "$env:SystemRoot\System32\shutdown.exe" -ArgumentList '/l'
    }
    Close-App
})
$ui.BtnSignOutLater.Add_Click({
    Write-JCLog "User selected I'll Sign Out Later"
    Send-Action 'sign_out_later'
    Close-App
})
$ui.BtnTogglePwd.Add_Click({
    if ($ui.TxtPasswordReveal.Visibility -eq 'Visible') {
        $ui.PwdPassword.Password = $ui.TxtPasswordReveal.Text
        $ui.TxtPasswordReveal.Clear()
        $ui.TxtPasswordReveal.Visibility = 'Collapsed'
        $ui.PwdPassword.Visibility = 'Visible'
        $ui.BtnTogglePwd.Content = 'Show'
        [void]$ui.PwdPassword.Focus()
    }
    else {
        $ui.TxtPasswordReveal.Text = $ui.PwdPassword.Password
        $ui.PwdPassword.Clear()
        $ui.PwdPassword.Visibility = 'Collapsed'
        $ui.TxtPasswordReveal.Visibility = 'Visible'
        $ui.BtnTogglePwd.Content = 'Hide'
        [void]$ui.TxtPasswordReveal.Focus()
        $ui.TxtPasswordReveal.CaretIndex = $ui.TxtPasswordReveal.Text.Length
    }
})
$ui.TxtEmail.Add_TextChanged({ Hide-Validation })
$ui.PwdPassword.Add_PasswordChanged({ Hide-Validation })
$ui.TxtPasswordReveal.Add_TextChanged({ Hide-Validation })

$window.Add_Closing({
    param($senderObj, $e)
    if ($script:AppClose) { return }
    if ($script:Phase -eq 'RESOLVING' -or $script:Phase -eq 'VERIFYING' -or $script:Phase -eq 'LINKING') {
        $answer = [System.Windows.MessageBox]::Show(
            'Account linking is still in progress. Close anyway?',
            'JumpCloud Account Setup',
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Warning)
        if ($answer -ne [System.Windows.MessageBoxResult]::Yes) {
            $e.Cancel = $true
            return
        }
    }
    Write-JCLog 'Window closed by user'
    Send-Action 'closed'
})

$window.Add_ContentRendered({
    Write-JCLog ("Window rendered and interactive at {0} ms after start" -f `
        $script:StartupSw.ElapsedMilliseconds)
    Write-Heartbeat -Path $HbUiPath
    $timer.Start()
    # Warm the LDAP path off the UI thread so the first Verify click never
    # pays a one-time assembly/JIT cost while the user is waiting.
    try {
        $warm = [powershell]::Create()
        [void]$warm.AddScript({
            try {
                Add-Type -AssemblyName System.DirectoryServices.Protocols -ErrorAction Stop
                $null = New-Object System.DirectoryServices.Protocols.LdapConnection('warmup:636')
            } catch { }
        })
        [void]$warm.BeginInvoke()
    }
    catch { }
})

# --- Initial screen ---------------------------------------------------
$initialState = ''
try { $initialState = [string]$cfg.InitialState } catch { }
if ($initialState -eq 'BLOCKED') {
    $blockedRef = ''
    try { $blockedRef = [string]$cfg.BlockedCategory } catch { }
    $ui.TxtBlockedMsg.Text = "This device is managed in a way that prevents automatic account linking. Please contact $SupportContact for help getting set up."
    if (-not [string]::IsNullOrEmpty($blockedRef)) {
        $ui.TxtBlockedRef.Text = "Support reference: $blockedRef"
    }
    Show-Screen 'BLOCKED'
}
else {
    Show-Screen 'WELCOME'
}

Write-JCLog ("Showing window at {0} ms after start" -f $script:StartupSw.ElapsedMilliseconds)
[void]$window.ShowDialog()

# --- Shutdown hygiene -------------------------------------------------
$timer.Stop()
Clear-PendingPassword
if ($script:AsyncPs) {
    try { $script:AsyncPs.Stop() } catch { }
    try { $script:AsyncPs.Dispose() } catch { }
}
Write-JCLog 'UI exited'
exit 0
