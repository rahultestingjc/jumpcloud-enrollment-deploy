# =====================================================================
# JCEnrollment.Logging - diagnostic logging (no credentials, no secrets)
# =====================================================================

$script:LogPath   = $null
$script:Component = 'Main'

function Initialize-JCLog {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [string]$Component = 'Main'
    )
    $dir = Split-Path -Parent $Path
    if ($dir -and !(Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    $script:LogPath   = $Path
    $script:Component = $Component
}

function Write-JCLog {
    param(
        [Parameter(Mandatory = $true)][string]$Message,
        [ValidateSet('DEBUG', 'INFO', 'WARN', 'ERROR')][string]$Level = 'INFO'
    )
    $line = '{0} [{1,-5}] [{2}] {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $script:Component, $Message
    if ($script:LogPath) {
        # Tolerate transient locks from concurrent writers.
        for ($i = 0; $i -lt 3; $i++) {
            try {
                Add-Content -Path $script:LogPath -Value $line -Encoding UTF8 -ErrorAction Stop
                break
            }
            catch { Start-Sleep -Milliseconds 50 }
        }
    }
    try { Write-Host $line } catch { }
}

function Get-MaskedEmail {
    # r***@example.com - keeps logs useful while minimizing PII exposure.
    param([string]$Email)
    if ([string]::IsNullOrWhiteSpace($Email)) { return '<empty>' }
    $parts = $Email.Split('@')
    if ($parts.Count -ne 2 -or $parts[0].Length -lt 1) { return '<invalid>' }
    $local = $parts[0]
    if ($local.Length -le 2) {
        $masked = $local.Substring(0, 1) + '*'
    }
    else {
        $masked = $local.Substring(0, 2) + ('*' * ($local.Length - 2))
    }
    return "$masked@$($parts[1])"
}

Export-ModuleMember -Function Initialize-JCLog, Write-JCLog, Get-MaskedEmail
