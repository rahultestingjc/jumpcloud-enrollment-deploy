# =====================================================================
# JCEnrollment.Ipc - file-based message exchange between the SYSTEM
# orchestrator and the user-session UI.
#
# Protocol: one JSON file per direction (request.json UI->SYSTEM,
# status.json SYSTEM->UI). Each message carries a monotonically
# increasing 'seq'; readers ignore anything at or below the last seq
# they processed, so files are only ever overwritten, never deleted
# mid-session. Content is strictly non-secret (emails, state names).
# Passwords NEVER transit this channel.
# =====================================================================

function Write-IpcMessage {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][hashtable]$Message
    )
    $Message['ts'] = (Get-Date).ToUniversalTime().ToString('o')
    $json = $Message | ConvertTo-Json -Depth 6 -Compress
    for ($i = 0; $i -lt 5; $i++) {
        try {
            Set-Content -Path $Path -Value $json -Encoding UTF8 -Force -ErrorAction Stop
            return $true
        }
        catch { Start-Sleep -Milliseconds 100 }
    }
    return $false
}

function Read-IpcMessage {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [long]$AfterSeq = -1
    )
    if (!(Test-Path $Path)) { return $null }
    try {
        $raw = Get-Content -Path $Path -Raw -Encoding UTF8 -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
        $obj = $raw | ConvertFrom-Json -ErrorAction Stop
        if ($null -eq $obj.PSObject.Properties['seq']) { return $null }
        if ([long]$obj.seq -le $AfterSeq) { return $null }
        return $obj
    }
    catch {
        # Partial write / transient lock - caller retries on its next tick.
        return $null
    }
}

function Write-Heartbeat {
    param([Parameter(Mandatory = $true)][string]$Path)
    try {
        Set-Content -Path $Path -Value ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) -Force -ErrorAction Stop
    }
    catch { }
}

function Get-HeartbeatAgeSeconds {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (!(Test-Path $Path)) { return [double]::MaxValue }
    try {
        $v = [long]((Get-Content -Path $Path -Raw -ErrorAction Stop).Trim())
        return [double]([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $v)
    }
    catch { return [double]::MaxValue }
}

Export-ModuleMember -Function Write-IpcMessage, Read-IpcMessage, Write-Heartbeat, Get-HeartbeatAgeSeconds
