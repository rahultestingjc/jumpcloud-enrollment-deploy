@{
    # =====================================================================
    # JumpCloud Device Enrollment - environment configuration (NO SECRETS)
    #
    # The JumpCloud API key and device id are NOT stored here. They are
    # injected by the JumpCloud command runner via the {{Apikey}} and
    # {{device.id}} template variables (see dist build / README).
    # =====================================================================

    JumpCloud = @{
        # EU-region tenants: 'https://console.eu.jumpcloud.com/api'
        BaseUri = 'https://console.jumpcloud.com/api'
    }

    Ldap = @{
        # JumpCloud Cloud LDAP (https://jumpcloud.com/support/use-cloud-ldap)
        Server = 'ldap.jumpcloud.com'

        # 636 = LDAPS (UseSsl), 389 = STARTTLS (UseStartTls). JumpCloud does
        # not allow plaintext LDAP; this tool refuses it as well.
        Port   = 636
        UseSsl      = $true
        UseStartTls = $false

        # Hard safety switch: when $true (default) any configuration that
        # would produce an unencrypted connection is rejected outright.
        RequireSecureConnection = $true

        TimeoutSeconds = 15

        # --- Authentication mode -----------------------------------------
        # DirectBind (recommended): the end user binds as themselves.
        #   The user's JumpCloud username is resolved from their email by the
        #   SYSTEM-side orchestrator (existing API lookup) and substituted
        #   into UserDnTemplate. No service account credential is needed on
        #   the endpoint. The user must be enabled for LDAP in JumpCloud.
        #
        # SearchThenBind: a service (LDAP binding user) account searches for
        #   the user's DN first, then the user's own bind is attempted.
        #   SECURITY: this places a reusable privileged credential on every
        #   endpoint. Strongly discouraged - see README "LDAP security".
        AuthMode = 'DirectBind'

        # Placeholders: {username} = JumpCloud username, {email} = entered email.
        # Org DN: o=650142a889027a0c688bdb9f,dc=jumpcloud,dc=com
        UserDnTemplate = 'uid={username},ou=Users,o=650142a889027a0c688bdb9f,dc=jumpcloud,dc=com'

        # --- SearchThenBind mode only ------------------------------------
        # (Unused while AuthMode = 'DirectBind'; kept configured so the mode
        # can be switched without hunting for values.)
        SearchBaseDn         = 'ou=Users,o=650142a889027a0c688bdb9f,dc=jumpcloud,dc=com'
        SearchFilterTemplate = '(&(objectClass=inetOrgPerson)(mail={email}))'
        # If ever switching to SearchThenBind: the LDAP binding user is
        # 'ldavsvc' (DN: uid=ldavsvc,ou=Users,o=<org>,dc=jumpcloud,dc=com -
        # confirm against the account's LDAP DN in the JumpCloud console).
        # Left empty here because DirectBind never uses it and this file
        # ships inside the deployment package.
        ServiceAccountDn     = ''
        # Do NOT put a reusable service-account password here. If your org
        # insists on SearchThenBind, deliver the secret at runtime from a
        # protected source (see README). A value here is treated as a
        # last-resort override and logged as a security warning.
        ServiceAccountSecret = ''
    }

    Defer = @{
        # "Remind Me Later" snooze. The enrollment command should be scheduled
        # to repeat (see README); while a defer is active the script exits
        # quietly without prompting the user.
        Minutes  = 120
        # 0 = unlimited defers. When the limit is reached the defer button is
        # no longer offered (mirrors the migration-deadline pattern).
        MaxCount = 0
        # Optional hard deadline (UTC, ISO-8601 e.g. '2026-10-01T00:00:00Z').
        # After this moment "Remind Me Later" is no longer offered.
        DeadlineUtc = ''
    }

    Ui = @{
        CompanyName    = 'Your Organization'
        AccentColor    = '#0E8A5F'
        # Optional absolute path to an OFFICIAL JumpCloud/company logo PNG
        # placed on the device. When empty, a neutral glyph is shown instead
        # (the tool never fabricates a JumpCloud logo).
        LogoPath       = ''
        SupportContact = 'your IT administrator'
    }

    Timeouts = @{
        # Whole-interaction cap. The JumpCloud command timeout MUST be set
        # higher than this (README: deployment).
        InteractionTimeoutMinutes   = 60
        # UI-side wait for the orchestrator to resolve email -> JC user.
        ResolveTimeoutSeconds       = 45
        # UI-side wait for the binding pipeline to report success/failure.
        BindingStatusTimeoutSeconds = 300
    }
}
