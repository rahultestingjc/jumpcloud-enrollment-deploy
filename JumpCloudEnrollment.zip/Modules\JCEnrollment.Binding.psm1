# =====================================================================
# JCEnrollment.Binding - JumpCloud device-binding operations.
#
# This is the existing, proven binding logic from the original
# Invoke-DeviceEnrollment.ps1, refactored into functions. The API
# behavior (endpoints, bodies, block conditions, username-alignment
# fallback order, failure description) is preserved deliberately.
# Runs in the SYSTEM orchestrator only - this module never sees the
# user's password.
# =====================================================================

function _BindLog {
    param([string]$Message, [string]$Level = 'INFO')
    if (Get-Command Write-JCLog -ErrorAction SilentlyContinue) { Write-JCLog $Message $Level }
}

function Invoke-JCApi {
    # Single choke point for all JumpCloud REST calls (also enables test
    # shimming of Invoke-RestMethod from the global scope).
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$ApiKey,
        $Body = $null
    )
    $headers = @{
        'x-api-key' = $ApiKey
        'Accept'    = 'application/json'
    }
    $params = @{
        Method      = $Method
        Uri         = $Uri
        Headers     = $headers
        ErrorAction = 'Stop'
    }
    if ($null -ne $Body) {
        $headers['Content-Type'] = 'application/json'
        $params['Body'] = ($Body | ConvertTo-Json -Depth 6)
    }
    return Invoke-RestMethod @params
}

function Get-JCUserByEmail {
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$BaseUri,
        [Parameter(Mandatory = $true)][string]$Email
    )
    $emailNorm = $Email.Trim().ToLower()
    $emailEsc  = [uri]::EscapeDataString($emailNorm)
    $resp = Invoke-JCApi -Method GET -Uri "$BaseUri/systemusers?filter=email:eq:$emailEsc" -ApiKey $ApiKey
    if (-not $resp.results) { return $null }
    return [pscustomobject]@{
        Id             = $resp.results[0]._id
        Username       = $resp.results[0].username
        SystemUsername = $resp.results[0].systemUsername
    }
}

function Get-InteractiveUserName {
    # Primary: console user (original script's method). Fallback: owner of
    # the interactive shell, which also covers RDP sessions where
    # Win32_ComputerSystem.UserName is empty.
    try {
        $u = (Get-CimInstance Win32_ComputerSystem).UserName
        if (-not [string]::IsNullOrWhiteSpace($u)) {
            return $u.Split('\')[-1].Trim()
        }
    }
    catch { }
    try {
        $shell = Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" | Select-Object -First 1
        if ($shell) {
            $owner = Invoke-CimMethod -InputObject $shell -MethodName GetOwner
            if ($owner -and -not [string]::IsNullOrWhiteSpace($owner.User)) {
                return $owner.User.Trim()
            }
        }
    }
    catch { }
    return $null
}

function Get-DeviceJoinState {
    param([string]$LocalUser)
    $state = [pscustomobject]@{
        IsDomainJoined  = $false
        IsAzureADJoined = $false
        IsMSAccount     = $false
    }
    try {
        if ((Get-CimInstance Win32_ComputerSystem).PartOfDomain) { $state.IsDomainJoined = $true }
    } catch { }
    try {
        $dsreg = & dsregcmd /status
        if ($dsreg -match 'AzureAdJoined\s*:\s*YES') { $state.IsAzureADJoined = $true }
    } catch { }
    try {
        if (-not [string]::IsNullOrWhiteSpace($LocalUser)) {
            $acct = Get-LocalUser | Where-Object { $_.Name -eq $LocalUser }
            if ($acct -and $acct.PrincipalSource -eq 'MicrosoftAccount') { $state.IsMSAccount = $true }
        }
    } catch { }
    return $state
}

function Get-DeviceBlockCategory {
    # Existing block conditions, unchanged.
    param([Parameter(Mandatory = $true)]$JoinState)
    if ($JoinState.IsDomainJoined)  { return 'DOMAIN_JOINED' }
    if ($JoinState.IsAzureADJoined) { return 'AAD_JOINED' }
    if ($JoinState.IsMSAccount)     { return 'MS_ACCOUNT' }
    return $null
}

function Invoke-JCUsernameAlignment {
    # The JumpCloud name this compares against - and renames to - is the
    # user's systemUsername when they have one, otherwise their username.
    # Everything else is the existing alignment behavior, unchanged:
    #  - local name contains a space           -> rename local user to JC name
    #  - otherwise: try systemUsername update  -> on failure, rename local user
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$BaseUri,
        [Parameter(Mandatory = $true)][string]$UserId,
        [Parameter(Mandatory = $true)][string]$JCUsername,
        [Parameter(Mandatory = $true)][string]$LocalUser,
        [AllowEmptyString()][AllowNull()][string]$JCSystemUsername = ''
    )

    # systemUsername wins when set; a null/blank value means "not present".
    $preferred = $JCUsername
    if (-not [string]::IsNullOrWhiteSpace($JCSystemUsername)) {
        $preferred = $JCSystemUsername.Trim()
        _BindLog 'Comparing against JumpCloud systemUsername' 'INFO'
    }

    if ($LocalUser.ToLower() -eq $preferred.ToLower()) {
        return @{ Success = $true; LocalUser = $LocalUser; FailureCategory = '' }
    }

    _BindLog 'Username mismatch detected' 'WARN'

    if ($LocalUser -match '\s') {
        _BindLog 'Local username contains space -> rename' 'INFO'
        try {
            Rename-LocalUser -Name $LocalUser -NewName $preferred -ErrorAction Stop
            _BindLog 'Rename successful' 'INFO'
            return @{ Success = $true; LocalUser = $preferred; FailureCategory = '' }
        }
        catch {
            _BindLog "Rename failed: $($_.Exception.Message)" 'ERROR'
            return @{ Success = $false; LocalUser = $LocalUser; FailureCategory = 'RENAME_FAILED' }
        }
    }

    _BindLog 'Attempting systemUsername update' 'INFO'
    try {
        Invoke-JCApi -Method PUT -Uri "$BaseUri/systemusers/$UserId" -ApiKey $ApiKey `
            -Body @{ systemUsername = $LocalUser } | Out-Null
        _BindLog 'systemUsername update succeeded' 'INFO'
        return @{ Success = $true; LocalUser = $LocalUser; FailureCategory = '' }
    }
    catch {
        _BindLog 'systemUsername update failed -> rename' 'WARN'
        try {
            Rename-LocalUser -Name $LocalUser -NewName $preferred -ErrorAction Stop
            _BindLog 'Rename successful' 'INFO'
            return @{ Success = $true; LocalUser = $preferred; FailureCategory = '' }
        }
        catch {
            _BindLog "Username alignment failed: $($_.Exception.Message)" 'ERROR'
            return @{ Success = $false; LocalUser = $LocalUser; FailureCategory = 'ALIGNMENT_FAILED' }
        }
    }
}

function Test-JCSystemAssociation {
    # Used to make retries idempotent: an "add" that fails because the
    # association already exists should count as success.
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$BaseUri,
        [Parameter(Mandatory = $true)][string]$UserId,
        [Parameter(Mandatory = $true)][string]$SystemId
    )
    try {
        $resp = Invoke-JCApi -Method GET -Uri "$BaseUri/v2/users/$UserId/systems" -ApiKey $ApiKey
        foreach ($entry in @($resp)) {
            if ($entry.id -eq $SystemId) { return $true }
        }
    }
    catch { }
    return $false
}

function Add-JCSystemAssociation {
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$BaseUri,
        [Parameter(Mandatory = $true)][string]$UserId,
        [Parameter(Mandatory = $true)][string]$SystemId
    )
    try {
        Invoke-JCApi -Method POST -Uri "$BaseUri/v2/users/$UserId/associations" -ApiKey $ApiKey `
            -Body @{ op = 'add'; type = 'system'; id = $SystemId } | Out-Null
        _BindLog 'Device binding succeeded' 'INFO'
        return $true
    }
    catch {
        if (Test-JCSystemAssociation -ApiKey $ApiKey -BaseUri $BaseUri -UserId $UserId -SystemId $SystemId) {
            _BindLog 'Association already exists - treating as success' 'INFO'
            return $true
        }
        _BindLog "Device binding failed: $($_.Exception.Message)" 'ERROR'
        return $false
    }
}

function Set-JCPrimarySystemUser {
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$BaseUri,
        [Parameter(Mandatory = $true)][string]$UserId,
        [Parameter(Mandatory = $true)][string]$SystemId
    )
    try {
        Invoke-JCApi -Method PUT -Uri "$BaseUri/systems/$SystemId" -ApiKey $ApiKey `
            -Body @{ primarySystemUser = @{ id = $UserId } } | Out-Null
        _BindLog 'Primary user set succeeded' 'INFO'
        return $true
    }
    catch {
        _BindLog "Set primary user failed: $($_.Exception.Message)" 'ERROR'
        return $false
    }
}

function Set-JCSystemDescription {
    # Existing failure-diagnostics behavior: surface the outcome on the
    # device record so IT can see it in the JumpCloud console.
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$BaseUri,
        [Parameter(Mandatory = $true)][string]$SystemId,
        [Parameter(Mandatory = $true)][string]$Description
    )
    try {
        Invoke-JCApi -Method PUT -Uri "$BaseUri/systems/$SystemId" -ApiKey $ApiKey `
            -Body @{ description = $Description } | Out-Null
        return $true
    }
    catch {
        _BindLog 'Failed to update device description' 'WARN'
        return $false
    }
}

function Invoke-JCDeviceBinding {
    <#
    .SYNOPSIS
        Full binding pipeline: username alignment -> associate -> primary user.
    .OUTPUTS
        Hashtable: Success (bool), LocalUser (possibly renamed),
        FailureCategory ('' | RENAME_FAILED | ALIGNMENT_FAILED |
        ASSOCIATION_FAILED | PRIMARY_USER_FAILED | <simulated>)
    #>
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$BaseUri,
        [Parameter(Mandatory = $true)][string]$SystemId,
        [Parameter(Mandatory = $true)]$User,          # @{ Id; Username; SystemUsername } from Get-JCUserByEmail
        [Parameter(Mandatory = $true)][string]$LocalUser,
        [string]$SimulateOutcome = ''                  # test builds only
    )

    if (-not [string]::IsNullOrEmpty($SimulateOutcome)) {
        _BindLog "Binding simulation active: $SimulateOutcome" 'WARN'
        Start-Sleep -Seconds 2
        if ($SimulateOutcome -eq 'success') {
            return @{ Success = $true; LocalUser = $LocalUser; FailureCategory = '' }
        }
        return @{ Success = $false; LocalUser = $LocalUser; FailureCategory = $SimulateOutcome.ToUpper() }
    }

    $jcSystemUser = ''
    if ($null -ne $User.SystemUsername) { $jcSystemUser = [string]$User.SystemUsername }

    $align = Invoke-JCUsernameAlignment -ApiKey $ApiKey -BaseUri $BaseUri `
        -UserId $User.Id -JCUsername $User.Username -LocalUser $LocalUser `
        -JCSystemUsername $jcSystemUser
    if (-not $align.Success) {
        return @{ Success = $false; LocalUser = $align.LocalUser; FailureCategory = $align.FailureCategory }
    }

    _BindLog 'Binding device' 'INFO'
    if (-not (Add-JCSystemAssociation -ApiKey $ApiKey -BaseUri $BaseUri -UserId $User.Id -SystemId $SystemId)) {
        return @{ Success = $false; LocalUser = $align.LocalUser; FailureCategory = 'ASSOCIATION_FAILED' }
    }

    _BindLog "Setting primary user: $($User.Id)" 'INFO'
    if (-not (Set-JCPrimarySystemUser -ApiKey $ApiKey -BaseUri $BaseUri -UserId $User.Id -SystemId $SystemId)) {
        return @{ Success = $false; LocalUser = $align.LocalUser; FailureCategory = 'PRIMARY_USER_FAILED' }
    }

    return @{ Success = $true; LocalUser = $align.LocalUser; FailureCategory = '' }
}

Export-ModuleMember -Function Invoke-JCApi, Get-JCUserByEmail, Get-InteractiveUserName, Get-DeviceJoinState, `
    Get-DeviceBlockCategory, Invoke-JCUsernameAlignment, Test-JCSystemAssociation, Add-JCSystemAssociation, `
    Set-JCPrimarySystemUser, Set-JCSystemDescription, Invoke-JCDeviceBinding
