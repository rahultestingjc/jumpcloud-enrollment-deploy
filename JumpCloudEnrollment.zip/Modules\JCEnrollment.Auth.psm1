# =====================================================================
# JCEnrollment.Auth - JumpCloud Cloud LDAP credential validation.
#
# Runs inside the USER-SESSION UI process only. The password arrives as
# a SecureString, is handed to LdapConnection via NetworkCredential for
# the bind, and is never logged, persisted, or transmitted anywhere
# except inside the TLS-protected LDAP bind itself.
#
# Encryption is mandatory: a configuration that would produce a
# plaintext connection is rejected before any network activity
# (JumpCloud Cloud LDAP does not accept plaintext either).
# =====================================================================

function _AuthLog {
    param([string]$Message, [string]$Level = 'INFO')
    if (Get-Command Write-JCLog -ErrorAction SilentlyContinue) { Write-JCLog $Message $Level }
}

function Get-LdapFilterEscaped {
    # RFC 4515 filter-value escaping.
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $Value.ToCharArray()) {
        switch ($ch) {
            '\' { [void]$sb.Append('\5c') }
            '*' { [void]$sb.Append('\2a') }
            '(' { [void]$sb.Append('\28') }
            ')' { [void]$sb.Append('\29') }
            ([char]0) { [void]$sb.Append('\00') }
            default { [void]$sb.Append($ch) }
        }
    }
    return $sb.ToString()
}

function Get-LdapDnEscaped {
    # RFC 4514 escaping for a value placed inside a DN component.
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    $escaped = $Value -replace '([\\,\+"<>;=#])', '\$1'
    $escaped = $escaped -replace '^ ', '\ '
    $escaped = $escaped -replace ' $', '\ '
    return $escaped
}

function New-JCLdapConnection {
    param([Parameter(Mandatory = $true)]$LdapConfig)

    $port = [int]$LdapConfig.Port
    $identifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier(
        [string]$LdapConfig.Server, $port, $true, $false)
    $conn = New-Object System.DirectoryServices.Protocols.LdapConnection($identifier)
    $conn.SessionOptions.ProtocolVersion = 3
    $conn.AuthType = [System.DirectoryServices.Protocols.AuthType]::Basic

    $timeoutSec = 15
    try { if ([int]$LdapConfig.TimeoutSeconds -gt 0) { $timeoutSec = [int]$LdapConfig.TimeoutSeconds } } catch { }
    $conn.Timeout = [TimeSpan]::FromSeconds($timeoutSec)

    if ($LdapConfig.UseSsl -eq $true) {
        $conn.SessionOptions.SecureSocketLayer = $true
    }
    elseif ($LdapConfig.UseStartTls -eq $true) {
        $conn.SessionOptions.StartTransportLayerSecurity($null)
    }
    return $conn
}

function ConvertTo-LdapFailure {
    # Maps an exception from a bind/search to a coarse, non-enumerable
    # result category. Detail stays terse and non-sensitive.
    param([Parameter(Mandatory = $true)]$ErrorRecord)

    # PowerShell wraps .NET method exceptions (MethodInvocationException);
    # walk the inner chain to find the meaningful one.
    $ex = $ErrorRecord.Exception
    $depth = 0
    while ($ex -and $depth -lt 6) {
        if ($ex -is [System.DirectoryServices.Protocols.LdapException] -or
            $ex -is [System.DirectoryServices.Protocols.DirectoryOperationException] -or
            $ex -is [System.TimeoutException]) { break }
        if ($null -eq $ex.InnerException) { break }
        $ex = $ex.InnerException
        $depth++
    }

    if ($ex -is [System.DirectoryServices.Protocols.LdapException]) {
        $code = $ex.ErrorCode
        # 49 invalid credentials | 81 server down | 85 timeout
        if ($code -eq 49) {
            return [pscustomobject]@{ Result = 'InvalidCredentials'; Detail = 'LDAP result 49' }
        }
        if ($code -eq 85) {
            return [pscustomobject]@{ Result = 'Timeout'; Detail = "LDAP error $code" }
        }
        return [pscustomobject]@{ Result = 'Unavailable'; Detail = "LDAP error $code" }
    }
    if ($ex -is [System.DirectoryServices.Protocols.DirectoryOperationException]) {
        $rc = ''
        try { $rc = [string]$ex.Response.ResultCode } catch { }
        if ($rc -eq 'InvalidCredentials') {
            return [pscustomobject]@{ Result = 'InvalidCredentials'; Detail = 'directory op: invalid credentials' }
        }
        return [pscustomobject]@{ Result = 'Unavailable'; Detail = "directory op: $rc" }
    }
    if ($ex -is [System.TimeoutException]) {
        return [pscustomobject]@{ Result = 'Timeout'; Detail = 'client timeout' }
    }
    return [pscustomobject]@{ Result = 'Unavailable'; Detail = $ex.GetType().Name }
}

function Resolve-JCLdapUserDn {
    # SearchThenBind mode: locate the user's DN with the service (LDAP
    # binding user) account. See README for why DirectBind is preferred.
    param(
        [Parameter(Mandatory = $true)]$LdapConfig,
        [Parameter(Mandatory = $true)][string]$Email,
        [string]$Username = ''
    )

    if ([string]::IsNullOrWhiteSpace([string]$LdapConfig.ServiceAccountDn)) {
        return [pscustomobject]@{ Result = 'ConfigError'; Detail = 'SearchThenBind requires ServiceAccountDn.' }
    }
    $secret = [string]$LdapConfig.ServiceAccountSecret
    if ([string]::IsNullOrEmpty($secret)) {
        return [pscustomobject]@{ Result = 'ConfigError'; Detail = 'SearchThenBind requires a service credential (see README for secure delivery).' }
    }
    _AuthLog 'SECURITY WARNING: SearchThenBind with an on-endpoint service credential is in use. DirectBind is recommended.' 'WARN'

    $conn = $null
    try {
        $conn = New-JCLdapConnection -LdapConfig $LdapConfig
        $svcSecure = ConvertTo-SecureString -String $secret -AsPlainText -Force
        $svcCred = New-Object System.Net.NetworkCredential([string]$LdapConfig.ServiceAccountDn, $svcSecure)
        $conn.Bind($svcCred)

        $filter = ([string]$LdapConfig.SearchFilterTemplate).
            Replace('{email}', (Get-LdapFilterEscaped $Email)).
            Replace('{username}', (Get-LdapFilterEscaped $Username))
        $request = New-Object System.DirectoryServices.Protocols.SearchRequest(
            [string]$LdapConfig.SearchBaseDn, $filter,
            [System.DirectoryServices.Protocols.SearchScope]::Subtree, @('distinguishedName'))
        $response = $conn.SendRequest($request)

        if ($response.Entries.Count -lt 1) {
            # Reported as InvalidCredentials so the caller cannot distinguish
            # "no such user" from "wrong password" (anti-enumeration).
            _AuthLog 'LDAP search returned no matching entry.' 'WARN'
            return [pscustomobject]@{ Result = 'InvalidCredentials'; Detail = 'no matching directory entry' }
        }
        return [pscustomobject]@{ Result = 'Success'; Dn = $response.Entries[0].DistinguishedName; Detail = '' }
    }
    catch {
        return (ConvertTo-LdapFailure -ErrorRecord $_)
    }
    finally {
        if ($conn) { try { $conn.Dispose() } catch { } }
    }
}

function Test-JCLdapCredential {
    <#
    .SYNOPSIS
        Validates a user's JumpCloud credentials over encrypted LDAP.
    .OUTPUTS
        PSCustomObject with:
          Result : Success | InvalidCredentials | Unavailable | Timeout | ConfigError
          Detail : short non-sensitive diagnostic string
    #>
    param(
        [Parameter(Mandatory = $true)]$LdapConfig,
        [Parameter(Mandatory = $true)][string]$Username,
        [Parameter(Mandatory = $true)][string]$Email,
        [Parameter(Mandatory = $true)][System.Security.SecureString]$Password
    )

    # ---- Simulation hook (honored only when staged by a -TestMode run) ----
    $sim = ''
    try { if ($LdapConfig.PSObject.Properties['Simulate']) { $sim = [string]$LdapConfig.Simulate } } catch { }
    if (-not [string]::IsNullOrEmpty($sim)) {
        _AuthLog "LDAP simulation active: $sim" 'WARN'
        Start-Sleep -Milliseconds 900
        switch ($sim) {
            'success'     { return [pscustomobject]@{ Result = 'Success'; Detail = 'simulated' } }
            'invalid'     { return [pscustomobject]@{ Result = 'InvalidCredentials'; Detail = 'simulated' } }
            'unavailable' { return [pscustomobject]@{ Result = 'Unavailable'; Detail = 'simulated' } }
            'timeout'     { return [pscustomobject]@{ Result = 'Timeout'; Detail = 'simulated' } }
            default       { return [pscustomobject]@{ Result = 'ConfigError'; Detail = "unknown simulation '$sim'" } }
        }
    }

    # ---- Refuse anything that is not an encrypted connection ----
    $secure = ($LdapConfig.UseSsl -eq $true) -or ($LdapConfig.UseStartTls -eq $true)
    $requireSecure = $true
    try { if ($LdapConfig.RequireSecureConnection -eq $false) { $requireSecure = $false } } catch { }
    if (-not $secure) {
        if ($requireSecure) {
            _AuthLog 'Refusing plaintext LDAP connection (RequireSecureConnection).' 'ERROR'
            return [pscustomobject]@{ Result = 'ConfigError'; Detail = 'Encrypted LDAP (LDAPS/StartTLS) is required; plaintext refused.' }
        }
        _AuthLog 'RequireSecureConnection disabled AND no TLS configured - refusing anyway (JumpCloud does not allow plaintext LDAP).' 'ERROR'
        return [pscustomobject]@{ Result = 'ConfigError'; Detail = 'Plaintext LDAP is not supported.' }
    }

    try {
        Add-Type -AssemblyName System.DirectoryServices.Protocols -ErrorAction Stop
    }
    catch {
        return [pscustomobject]@{ Result = 'ConfigError'; Detail = 'System.DirectoryServices.Protocols unavailable.' }
    }

    # ---- Determine the bind DN ----
    $bindDn = $null
    if ([string]$LdapConfig.AuthMode -eq 'SearchThenBind') {
        $resolved = Resolve-JCLdapUserDn -LdapConfig $LdapConfig -Email $Email -Username $Username
        if ($resolved.Result -ne 'Success') { return $resolved }
        $bindDn = $resolved.Dn
    }
    else {
        $template = [string]$LdapConfig.UserDnTemplate
        if ([string]::IsNullOrWhiteSpace($template) -or $template -match 'YOUR_JUMPCLOUD_ORG_ID') {
            _AuthLog 'UserDnTemplate is not configured (org id placeholder present).' 'ERROR'
            return [pscustomobject]@{ Result = 'ConfigError'; Detail = 'UserDnTemplate is not configured.' }
        }
        $bindDn = $template.
            Replace('{username}', (Get-LdapDnEscaped $Username)).
            Replace('{email}', (Get-LdapDnEscaped $Email))
    }

    # ---- Bind as the user ----
    $conn = $null
    try {
        $conn = New-JCLdapConnection -LdapConfig $LdapConfig
        $cred = New-Object System.Net.NetworkCredential($bindDn, $Password)
        try {
            $conn.Bind($cred)
            _AuthLog 'LDAP bind succeeded.' 'INFO'
            return [pscustomobject]@{ Result = 'Success'; Detail = '' }
        }
        finally {
            $cred = $null
        }
    }
    catch {
        $failure = ConvertTo-LdapFailure -ErrorRecord $_
        _AuthLog "LDAP bind failed: $($failure.Result) ($($failure.Detail))" 'WARN'
        return $failure
    }
    finally {
        if ($conn) { try { $conn.Dispose() } catch { } }
    }
}

Export-ModuleMember -Function Test-JCLdapCredential, Resolve-JCLdapUserDn, New-JCLdapConnection, Get-LdapFilterEscaped, Get-LdapDnEscaped
