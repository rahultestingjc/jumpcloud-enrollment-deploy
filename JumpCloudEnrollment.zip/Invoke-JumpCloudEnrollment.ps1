# =====================================================================
# JumpCloud Device Enrollment - SYSTEM orchestrator
#
# Runs as the JumpCloud agent (SYSTEM) via an MDM command. Performs
# preflight checks, stages and launches the user-session UI, resolves
# the entered email to a JumpCloud user, and - after the UI reports a
# successful LDAP credential verification - executes the existing
# device-binding pipeline (username alignment, association, primary
# user). The user's password NEVER reaches this process.
#
# Deployment: run build\New-DeploymentScript.ps1 to produce the
# single-file version with {{Apikey}} / {{device.id}} template
# variables for the JumpCloud console (see README).
# =====================================================================
# PositionalBinding disabled: a stray unnamed argument must error loudly
# instead of silently binding to ApiKey.
[CmdletBinding(PositionalBinding = $false)]
param(
    [string]$ApiKey = '',
    [string]$SystemId = '',
    # TestMode: full local simulation for automated UI tests - same-session
    # UI launch, no ACLs. DryRun: pre-MDM validation AS SYSTEM - real
    # staging paths, ACLs, and RunAsUser user-session launch, but binding
    # simulated and sign-out suppressed (see tests\Invoke-SystemDryRun.ps1).
    [switch]$TestMode,
    [switch]$DryRun,
    # --- Tenant settings (normally supplied by the MDM command's TENANT
    # SETTINGS block; each one overrides the packaged config when set) ---
    [string]$OrgId = '',
    [string]$Region = '',            # 'US' or 'EU'
    [string]$CompanyName = '',
    [string]$SupportContact = '',
    [string]$AccentColor = '',
    [string]$LogoPath = '',
    [string]$LdapServer = '',
    [int]$LdapPort = 0,              # 636 = LDAPS, 389 = StartTLS
    # Everything staged on the device is deleted when the run ends. With
    # -KeepLogs the SYSTEM log and the user's ui.log survive for debugging.
    [switch]$KeepLogs,
    # Simulated modes only: overrides the LDAP outcome ('' = real LDAP bind).
    [string]$LdapSimulate = '',
    [string]$RootOverride = '',
    [string]$ConfigOverridePath = ''
)

# ===== BODY =====  (everything below is shared with the dist build)

$AppVersion = '2.0.0'

# Either simulated mode replaces the JumpCloud binding calls with
# simulations and suppresses sign-out; they differ in launch machinery.
$Simulated = [bool]$TestMode -or [bool]$DryRun

Set-ExecutionPolicy -Scope Process Bypass -Force
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ---------------------------------------------------------------------
# Paths & staging
# ---------------------------------------------------------------------
$Root = 'C:\ProgramData\JumpCloudEnrollment'
if (-not [string]::IsNullOrEmpty($RootOverride)) { $Root = $RootOverride }

$ModulesDir = Join-Path $Root 'Modules'
$UiDir      = Join-Path $Root 'UI'
$ConfigDir  = Join-Path $Root 'Config'
$IpcDir     = Join-Path $Root 'ipc'          # SYSTEM writes, user reads
$IpcUserDir = Join-Path $IpcDir 'ui'         # user writes, SYSTEM reads
$LogsDir    = Join-Path $Root 'Logs'

# ---------------------------------------------------------------------
# Locked staging folder
#
# SYSTEM loads code and config from $Root, and C:\ProgramData lets any
# user create folders, so the folder must be provably ours: leftovers are
# wiped, it is re-created with its permissions set at creation (SYSTEM +
# Administrators full control, Users read), and anything else stops the
# run. The only user-writable spot is ipc\ui, and SYSTEM only reads there.
# Deletes go through cmd's rmdir, which removes junctions and symlinks
# instead of following them. Test mode stages into a private temp folder
# and skips all of this.
# ---------------------------------------------------------------------
function Test-JCTrustedFolder {
    # A real folder (not a link), owned by SYSTEM or Administrators, with
    # no inherited permissions and no write-type right for anyone else.
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [string[]]$TrustedSids = @('S-1-5-18', 'S-1-5-32-544')
    )
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    if (-not $item -or -not $item.PSIsContainer) { return $false }
    if ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) { return $false }
    try { $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop } catch { return $false }
    $sidType = [System.Security.Principal.SecurityIdentifier]
    if ($TrustedSids -notcontains $acl.GetOwner($sidType).Value) { return $false }
    if (-not $acl.AreAccessRulesProtected) { return $false }
    # Specific write/delete/ownership rights, plus GENERIC_ALL and GENERIC_WRITE.
    $writeRights = 'WriteData, AppendData, WriteExtendedAttributes, WriteAttributes, ' +
        'Delete, DeleteSubdirectoriesAndFiles, ChangePermissions, TakeOwnership'
    $writeMask = [long][System.Security.AccessControl.FileSystemRights]$writeRights
    $writeMask = $writeMask -bor 0x10000000 -bor 0x40000000
    foreach ($rule in $acl.GetAccessRules($true, $true, $sidType)) {
        if ($rule.AccessControlType -ne 'Allow') { continue }
        if ($TrustedSids -contains $rule.IdentityReference.Value) { continue }
        if (([long]$rule.FileSystemRights -band $writeMask) -ne 0) { return $false }
    }
    return $true
}

function Remove-JCFolder {
    # Returns $true once nothing exists at $Path.
    param([Parameter(Mandatory = $true)][string]$Path)
    for ($i = 0; $i -lt 5; $i++) {
        $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
        if (-not $item) { return $true }
        if ($item.PSIsContainer) { & cmd.exe /d /c rmdir /s /q $Path 2>$null | Out-Null }
        else { Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue }
        if (Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue) {
            Start-Sleep -Milliseconds 400   # a file may still be open briefly
        }
    }
    return -not (Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue)
}

function New-JCLockedFolder {
    # CreateDirectory applies the permissions itself, so the folder is never
    # briefly open. Refuses a path that already exists: that could be a
    # folder someone else planted.
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$UsersRead,
        [string[]]$TrustedSids = @('S-1-5-18', 'S-1-5-32-544')
    )
    if (Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue) { return $false }
    $inherit = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
    $security = New-Object System.Security.AccessControl.DirectorySecurity
    $security.SetAccessRuleProtection($true, $false)
    $grants = @()
    foreach ($sid in $TrustedSids) { $grants += , @($sid, 'FullControl') }
    if ($UsersRead) { $grants += , @('S-1-5-32-545', 'ReadAndExecute') }
    foreach ($grant in $grants) {
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            (New-Object System.Security.Principal.SecurityIdentifier($grant[0])),
            $grant[1], $inherit, 'None', 'Allow')
        $security.AddAccessRule($rule)
    }
    try { [void][System.IO.Directory]::CreateDirectory($Path, $security) }
    catch { return $false }
    # If someone raced us to the name, CreateDirectory returned their folder.
    return (Test-JCTrustedFolder -Path $Path -TrustedSids $TrustedSids)
}

function Clear-JCStaging {
    # Self-destruct: removes everything staged under $StagingRoot. With
    # -KeepLogs the Logs folder survives and everything else goes.
    param(
        [Parameter(Mandatory = $true)][string]$StagingRoot,
        [switch]$KeepLogs
    )
    if (-not $KeepLogs) { return (Remove-JCFolder -Path $StagingRoot) }
    $ok = $true
    foreach ($child in @(Get-ChildItem -LiteralPath $StagingRoot -Force -ErrorAction SilentlyContinue)) {
        if ($child.Name -eq 'Logs') { continue }
        if (-not (Remove-JCFolder -Path $child.FullName)) { $ok = $false }
    }
    return $ok
}

function Initialize-JCStaging {
    # Builds the locked layout under $StagingRoot and returns $true, or
    # returns $false when it cannot prove the folders are ours. A previous
    # run's logs are kept only with -KeepLogs, and only when the folders
    # holding them are trusted.
    param(
        [Parameter(Mandatory = $true)][string]$StagingRoot,
        [switch]$KeepLogs,
        [string[]]$TrustedSids = @('S-1-5-18', 'S-1-5-32-544')
    )
    $logs = Join-Path $StagingRoot 'Logs'
    $ipc = Join-Path $StagingRoot 'ipc'
    $reuse = $KeepLogs -and (Test-JCTrustedFolder -Path $StagingRoot -TrustedSids $TrustedSids) -and
        (Test-JCTrustedFolder -Path $logs -TrustedSids $TrustedSids)
    if ($reuse) {
        if (-not (Clear-JCStaging -StagingRoot $StagingRoot -KeepLogs)) { return $false }
    }
    else {
        if (-not (Remove-JCFolder -Path $StagingRoot)) { return $false }
        if (-not (New-JCLockedFolder -Path $StagingRoot -UsersRead -TrustedSids $TrustedSids)) { return $false }
        # Logs: SYSTEM + Administrators only (emails, device diagnostics).
        if (-not (New-JCLockedFolder -Path $logs -TrustedSids $TrustedSids)) { return $false }
    }
    foreach ($name in @('Modules', 'UI', 'Config', 'ipc', 'ipc\ui')) {
        try { New-Item -ItemType Directory -Path (Join-Path $StagingRoot $name) -ErrorAction Stop | Out-Null }
        catch { return $false }
    }
    # INTERACTIVE may create and overwrite its request and heartbeat files.
    & icacls (Join-Path $ipc 'ui') /grant '*S-1-5-4:(OI)(CI)M' | Out-Null
    return ($LASTEXITCODE -eq 0)
}

if ($TestMode) {
    foreach ($dir in @($Root, $ModulesDir, $UiDir, $ConfigDir, $IpcDir, $IpcUserDir, $LogsDir)) {
        if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    }
}
elseif (-not (Initialize-JCStaging -StagingRoot $Root -KeepLogs:$KeepLogs)) {
    Write-Host 'Status: RequiresAction | Issue: Staging folder could not be secured'
    Write-Host "Detail: $Root exists and is not owned by SYSTEM/Administrators, or is locked"
    exit 1
}

function Exit-JCEnrollment {
    # Every exit after staging goes through here so the device is left clean.
    param([int]$Code)
    if (-not $TestMode) {
        Stop-JCLog
        [void](Clear-JCStaging -StagingRoot $Root -KeepLogs:$KeepLogs)
    }
    exit $Code
}

# $script:EmbeddedFiles is defined by the dist build; when empty (repo
# layout) files are copied from the source tree next to this script.
if (-not (Get-Variable -Name EmbeddedFiles -Scope Script -ErrorAction SilentlyContinue)) {
    $script:EmbeddedFiles = @{}
}
if ($script:EmbeddedFiles.Count -gt 0) {
    foreach ($relPath in $script:EmbeddedFiles.Keys) {
        $target = Join-Path $Root $relPath
        $targetDir = Split-Path -Parent $target
        if (!(Test-Path $targetDir)) { New-Item -ItemType Directory -Path $targetDir -Force | Out-Null }
        [System.IO.File]::WriteAllBytes($target, [Convert]::FromBase64String($script:EmbeddedFiles[$relPath]))
    }
}
else {
    $srcRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
    Copy-Item -Path (Join-Path $srcRoot 'Modules\*.psm1') -Destination $ModulesDir -Force
    Copy-Item -Path (Join-Path $srcRoot 'UI\EnrollmentUI.ps1') -Destination $UiDir -Force
    Copy-Item -Path (Join-Path $srcRoot 'Config\enrollment.config.psd1') -Destination $ConfigDir -Force
}

Import-Module (Join-Path $ModulesDir 'JCEnrollment.Logging.psm1') -Force
Import-Module (Join-Path $ModulesDir 'JCEnrollment.Ipc.psm1') -Force
Import-Module (Join-Path $ModulesDir 'JCEnrollment.Binding.psm1') -Force

Initialize-JCLog -Path (Join-Path $LogsDir 'enrollment.log') -Component 'Orchestrator'
Write-JCLog "===== Enrollment started (version $AppVersion) ====="
Write-JCLog "Running context: $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
if ($TestMode) { Write-JCLog 'TEST MODE ACTIVE - external effects are simulated' 'WARN' }
if ($DryRun) { Write-JCLog 'DRY RUN ACTIVE - real SYSTEM/user-session machinery, binding simulated' 'WARN' }
if (-not $TestMode) {
    Write-JCLog "Staging folder locked: $Root (removed at the end of the run; KeepLogs=$([bool]$KeepLogs))"
}

# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------
$configPath = Join-Path $ConfigDir 'enrollment.config.psd1'
if (-not [string]::IsNullOrEmpty($ConfigOverridePath)) { $configPath = $ConfigOverridePath }
try {
    $Config = Import-PowerShellDataFile -Path $configPath
}
catch {
    Write-JCLog "Failed to load configuration '$configPath': $($_.Exception.Message)" 'ERROR'
    Write-Host 'Status: RequiresAction | Issue: Configuration load failed'
    Exit-JCEnrollment 1
}

# ---------------------------------------------------------------------
# Tenant overrides (from the MDM command's TENANT SETTINGS block)
# ---------------------------------------------------------------------
if (-not [string]::IsNullOrWhiteSpace($OrgId)) {
    $Config.Ldap.UserDnTemplate = 'uid={username},ou=Users,o=' + $OrgId + ',dc=jumpcloud,dc=com'
    $Config.Ldap.SearchBaseDn   = 'ou=Users,o=' + $OrgId + ',dc=jumpcloud,dc=com'
    Write-JCLog "Tenant override: OrgId set ($OrgId)"
}
if ($Region -match '^(?i)eu$') { $Config.JumpCloud.BaseUri = 'https://console.eu.jumpcloud.com/api' }
elseif ($Region -match '^(?i)us$') { $Config.JumpCloud.BaseUri = 'https://console.jumpcloud.com/api' }
elseif (-not [string]::IsNullOrWhiteSpace($Region)) {
    Write-JCLog "Unknown Region '$Region' ignored (use US or EU)" 'WARN'
}
if (-not [string]::IsNullOrWhiteSpace($CompanyName))    { $Config.Ui.CompanyName = $CompanyName }
if (-not [string]::IsNullOrWhiteSpace($SupportContact)) { $Config.Ui.SupportContact = $SupportContact }
if (-not [string]::IsNullOrWhiteSpace($AccentColor))    { $Config.Ui.AccentColor = $AccentColor }
if (-not [string]::IsNullOrWhiteSpace($LogoPath))       { $Config.Ui.LogoPath = $LogoPath }
if (-not [string]::IsNullOrWhiteSpace($LdapServer)) { $Config.Ldap.Server = $LdapServer }
if ($LdapPort -gt 0) {
    $Config.Ldap.Port = $LdapPort
    if ($LdapPort -eq 389) { $Config.Ldap.UseSsl = $false; $Config.Ldap.UseStartTls = $true }
    else { $Config.Ldap.UseSsl = $true; $Config.Ldap.UseStartTls = $false }
}
# Fail fast with a clear message when the tenant never set their Org ID.
if (-not $Simulated -and ([string]$Config.Ldap.UserDnTemplate) -match 'YOUR_JUMPCLOUD_ORG_ID') {
    Write-JCLog 'Org ID not configured - set $OrgId in the MDM command TENANT SETTINGS.' 'ERROR'
    Write-Host 'Status: RequiresAction | Issue: OrgId not set (edit the TENANT SETTINGS in the command)'
    Exit-JCEnrollment 1
}

$BaseUri = [string]$Config.JumpCloud.BaseUri
$InteractionTimeoutMin = 60
try { if ([int]$Config.Timeouts.InteractionTimeoutMinutes -gt 0) { $InteractionTimeoutMin = [int]$Config.Timeouts.InteractionTimeoutMinutes } } catch { }

# Test-scenario knobs (only honored in simulated modes).
$TestScenario = $null
if ($Simulated -and $Config.ContainsKey('Test')) { $TestScenario = $Config.Test }

if (-not $Simulated) {
    if ([string]::IsNullOrWhiteSpace($ApiKey) -or [string]::IsNullOrWhiteSpace($SystemId)) {
        Write-JCLog 'ApiKey/SystemId missing - this script must run via the JumpCloud command with template variables.' 'ERROR'
        Write-Host 'Status: RequiresAction | Issue: Missing ApiKey/SystemId'
        Exit-JCEnrollment 1
    }
}
else {
    # Simulated pipelines never bind the device, but parameters must bind.
    # A REAL ApiKey may still be passed to a DryRun to exercise the real
    # email -> JumpCloud user lookup (read-only).
    if ([string]::IsNullOrWhiteSpace($ApiKey)) { $ApiKey = 'TEST-API-KEY' }
    if ([string]::IsNullOrWhiteSpace($SystemId)) { $SystemId = 'TEST-SYSTEM-ID' }
}
Write-JCLog "SystemID: $SystemId"

# ---------------------------------------------------------------------
# Remind Me Later availability. No state is kept on the device: every
# run prompts (unless nobody is signed in), and "Remind Me Later" simply
# closes the window until the command runs again.
# ---------------------------------------------------------------------
$AllowDefer = $true
try {
    $deadlineRaw = [string]$Config.Defer.DeadlineUtc
    if (-not [string]::IsNullOrEmpty($deadlineRaw)) {
        $deadline = [datetime]::Parse($deadlineRaw, $null, [System.Globalization.DateTimeStyles]::RoundtripKind)
        if ((Get-Date).ToUniversalTime() -ge $deadline.ToUniversalTime()) { $AllowDefer = $false }
    }
} catch { }
if (-not $AllowDefer) { Write-JCLog 'Defer deadline passed - Remind Me Later will not be offered.' 'WARN' }

# ---------------------------------------------------------------------
# RunAsUser module (existing prerequisite logic, unchanged)
# ---------------------------------------------------------------------
if (-not $TestMode) {
    try {
        if (-not (Get-Module -ListAvailable -Name RunAsUser)) {
            Write-JCLog 'RunAsUser not found. Installing prerequisites...'
            if (-not (Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue)) {
                Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope AllUsers | Out-Null
            }
            if (-not (Get-PSRepository -Name PSGallery -ErrorAction SilentlyContinue)) {
                Register-PSRepository -Default
            }
            if ((Get-PSRepository -Name PSGallery).InstallationPolicy -ne 'Trusted') {
                Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
            }
            Install-Module -Name RunAsUser -Scope AllUsers -Force -AllowClobber -Confirm:$false -ErrorAction Stop
            Write-JCLog 'RunAsUser installed successfully.'
        }
        Import-Module RunAsUser -Force -ErrorAction Stop
    }
    catch {
        Write-JCLog "Failed to load RunAsUser module: $($_.Exception.Message)" 'ERROR'
        Write-Host 'Status: RequiresAction | Issue: RunAsUser unavailable'
        Exit-JCEnrollment 1
    }
}

# ---------------------------------------------------------------------
# Preflight: interactive user + device state (existing block conditions)
# ---------------------------------------------------------------------
$LocalUser = Get-InteractiveUserName
if ([string]::IsNullOrEmpty($LocalUser)) {
    Write-JCLog 'No interactive user logged on - cannot prompt. Exiting for a later retry.' 'WARN'
    Write-Host 'Status: Deferred | Issue: No interactive user'
    Exit-JCEnrollment 0
}
Write-JCLog "Local user: $LocalUser"

$JoinState = Get-DeviceJoinState -LocalUser $LocalUser
$BlockedCategory = Get-DeviceBlockCategory -JoinState $JoinState
if ($TestScenario -and $TestScenario.ContainsKey('ForceBlockedCategory') -and $TestScenario.ForceBlockedCategory) {
    $BlockedCategory = [string]$TestScenario.ForceBlockedCategory
}
if ($BlockedCategory) { Write-JCLog "Device blocked from enrollment: $BlockedCategory" 'WARN' }

# ---------------------------------------------------------------------
# Runtime config for the UI (non-secret) + IPC channel
# ---------------------------------------------------------------------
# SYSTEM writes only into ipc (users can read, not write) and only reads
# from ipc\ui, so a link planted in the user-writable folder can never
# redirect a SYSTEM write.
$ReqPath    = Join-Path $IpcUserDir 'request.json'
$HbUiPath   = Join-Path $IpcUserDir 'heartbeat_ui.txt'
$StatusPath = Join-Path $IpcDir 'status.json'
$HbSysPath  = Join-Path $IpcDir 'heartbeat_system.txt'
if ($TestMode) {
    # Real runs start from a freshly built folder; test roots are reused.
    foreach ($stale in @($ReqPath, $StatusPath, $HbSysPath, $HbUiPath)) {
        if (Test-Path $stale) { Remove-Item -Path $stale -Force -ErrorAction SilentlyContinue }
    }
}

$ldapRuntime = @{}
foreach ($key in $Config.Ldap.Keys) { $ldapRuntime[$key] = $Config.Ldap[$key] }
if ($Simulated -and -not [string]::IsNullOrEmpty($LdapSimulate)) {
    $ldapRuntime['Simulate'] = $LdapSimulate
}
elseif ($TestScenario -and $TestScenario.ContainsKey('LdapSimulate') -and $TestScenario.LdapSimulate) {
    $ldapRuntime['Simulate'] = [string]$TestScenario.LdapSimulate
}
else {
    # No simulation staged: the UI performs a REAL LDAPS bind (safe and
    # read-only - useful in DryRun to validate the DN template end to end).
    $ldapRuntime.Remove('Simulate') | Out-Null
}
# The UI never needs the service secret unless SearchThenBind is in use.
if ([string]$ldapRuntime['AuthMode'] -ne 'SearchThenBind') {
    $ldapRuntime['ServiceAccountDn'] = ''
    $ldapRuntime['ServiceAccountSecret'] = ''
}

$initialState = 'WELCOME'
if ($BlockedCategory) { $initialState = 'BLOCKED' }

$runtimeConfig = @{
    AppVersion      = $AppVersion
    InitialState    = $initialState
    BlockedCategory = $BlockedCategory
    LocalUser       = $LocalUser
    Ldap            = $ldapRuntime
    Ui              = $Config.Ui
    Timeouts        = $Config.Timeouts
    Defer           = @{
        AllowDefer = $AllowDefer
    }
    Paths           = @{ IpcDir = $IpcDir; IpcUserDir = $IpcUserDir }
    Logs            = @{ Keep = [bool]$KeepLogs }
    Test            = @{
        Enabled         = $Simulated
        SuppressSignOut = $Simulated
    }
}
$runtimeConfigPath = Join-Path $Root 'config.runtime.json'
$runtimeConfig | ConvertTo-Json -Depth 8 | Set-Content -Path $runtimeConfigPath -Encoding UTF8 -Force

# ---------------------------------------------------------------------
# Launch the UI in the user's session
# ---------------------------------------------------------------------
Write-JCLog 'Launching enrollment UI in user session'
if ($TestMode) {
    $uiScript = Join-Path $UiDir 'EnrollmentUI.ps1'
    Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList @(
        '-NoProfile', '-Sta', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
        '-File', "`"$uiScript`"", '-ConfigPath', "`"$runtimeConfigPath`"") | Out-Null
}
else {
    # Constant staged path - the scriptblock runs in a separate process
    # and cannot capture variables.
    $uiLauncher = {
        & powershell.exe -NoProfile -Sta -ExecutionPolicy Bypass -WindowStyle Hidden `
            -File 'C:\ProgramData\JumpCloudEnrollment\UI\EnrollmentUI.ps1' `
            -ConfigPath 'C:\ProgramData\JumpCloudEnrollment\config.runtime.json'
    }
    Invoke-AsCurrentUser -ScriptBlock $uiLauncher -NoWait | Out-Null
}

# ---------------------------------------------------------------------
# Orchestration loop
# ---------------------------------------------------------------------
$statusSeq        = 0
$lastReqSeq       = 0
$loopDeadline     = (Get-Date).AddMinutes($InteractionTimeoutMin)
$loopStart        = Get-Date
$cachedUser       = $null
$cachedEmail      = ''
$bindingSucceeded = $false
$finalStatus      = 'RequiresAction'
$issueReason      = 'None'
$noteText         = ''
$jcUsername       = ''
$effectiveLocal   = $LocalUser
$simBindingQueue  = @()
$simBindingIndex  = 0
if ($TestScenario -and $TestScenario.ContainsKey('BindingResults')) {
    $simBindingQueue = @($TestScenario.BindingResults)
}

function Send-Status {
    param([hashtable]$Message)
    $script:statusSeq++
    $Message['seq'] = $script:statusSeq
    [void](Write-IpcMessage -Path $StatusPath -Message $Message)
}

function Invoke-BindingPipeline {
    # Runs the (existing) binding steps and reports the outcome to the UI.
    if ($null -eq $script:cachedUser) {
        Write-JCLog 'Binding requested but no resolved user is cached' 'ERROR'
        Send-Status @{ state = 'BINDING_FAILED'; category = 'NO_RESOLVED_USER' }
        $script:issueReason = 'No resolved user'
        return
    }
    Send-Status @{ state = 'LINKING' }
    Write-JCLog 'Binding pipeline started'

    $simOutcome = ''
    if ($Simulated) {
        if ($script:simBindingIndex -lt $script:simBindingQueue.Count) {
            $simOutcome = [string]$script:simBindingQueue[$script:simBindingIndex]
            $script:simBindingIndex++
        }
        else {
            $simOutcome = 'success'
        }
    }

    try {
        $result = Invoke-JCDeviceBinding -ApiKey $ApiKey -BaseUri $BaseUri -SystemId $SystemId `
            -User $script:cachedUser -LocalUser $script:effectiveLocal -SimulateOutcome $simOutcome
    }
    catch {
        Write-JCLog "Binding pipeline threw: $($_.Exception.Message)" 'ERROR'
        $result = @{ Success = $false; LocalUser = $script:effectiveLocal; FailureCategory = 'PIPELINE_ERROR' }
    }
    if (-not [string]::IsNullOrEmpty([string]$result.LocalUser)) {
        $script:effectiveLocal = [string]$result.LocalUser
    }

    if ($result.Success) {
        Write-JCLog 'Binding pipeline succeeded'
        $script:bindingSucceeded = $true
        $script:finalStatus = 'Good'
        $script:issueReason = 'None'
        Send-Status @{ state = 'SUCCESS' }
    }
    else {
        Write-JCLog "Binding pipeline failed: $($result.FailureCategory)" 'ERROR'
        $script:issueReason = [string]$result.FailureCategory
        Send-Status @{ state = 'BINDING_FAILED'; category = [string]$result.FailureCategory }
    }
}

$running = $true
while ($running) {
    Write-Heartbeat -Path $HbSysPath

    $request = Read-IpcMessage -Path $ReqPath -AfterSeq $lastReqSeq
    if ($request) {
        $lastReqSeq = [long]$request.seq
        $action = [string]$request.action
        Write-JCLog "Received UI action: $action"

        switch ($action) {
            'resolve_user' {
                $cachedEmail = ([string]$request.email).Trim().ToLower()
                Write-JCLog "Resolving JumpCloud user for $(Get-MaskedEmail $cachedEmail)"
                $resolved = $null
                # A DryRun given a real ApiKey performs the real (read-only)
                # lookup; otherwise simulated modes fake it.
                if ($Simulated -and $ApiKey -eq 'TEST-API-KEY') {
                    $simResolve = 'ok'
                    if ($TestScenario -and $TestScenario.ContainsKey('ResolveResult')) {
                        $simResolve = [string]$TestScenario.ResolveResult
                    }
                    Start-Sleep -Milliseconds 600
                    if ($simResolve -eq 'ok') {
                        $simUsername = $env:USERNAME
                        if ($TestScenario -and $TestScenario.ContainsKey('ResolvedUsername') -and $TestScenario.ResolvedUsername) {
                            $simUsername = [string]$TestScenario.ResolvedUsername
                        }
                        $simSystemUsername = ''
                        if ($TestScenario -and $TestScenario.ContainsKey('ResolvedSystemUsername')) {
                            $simSystemUsername = [string]$TestScenario.ResolvedSystemUsername
                        }
                        $resolved = [pscustomobject]@{
                            Id             = 'test-user-id'
                            Username       = $simUsername
                            SystemUsername = $simSystemUsername
                        }
                    }
                }
                else {
                    try {
                        $resolved = Get-JCUserByEmail -ApiKey $ApiKey -BaseUri $BaseUri -Email $cachedEmail
                    }
                    catch {
                        Write-JCLog "User lookup failed: $($_.Exception.Message)" 'ERROR'
                        $resolved = $null
                    }
                }

                if ($resolved) {
                    $cachedUser = $resolved
                    $jcUsername = $resolved.Username
                    Write-JCLog "JumpCloud user resolved: $($resolved.Username) ($($resolved.Id))"
                    Send-Status @{ state = 'USER_RESOLVED'; ok = $true; username = $resolved.Username }
                }
                else {
                    $cachedUser = $null
                    Write-JCLog 'JumpCloud user not found for entered email' 'WARN'
                    $issueReason = 'JumpCloud user not found'
                    Send-Status @{ state = 'USER_RESOLVED'; ok = $false }
                }
            }
            'auth_success' {
                Write-JCLog 'UI reports successful LDAP credential verification'
                Invoke-BindingPipeline
            }
            'retry_binding' {
                Write-JCLog 'UI requested binding retry'
                Invoke-BindingPipeline
            }
            'defer' {
                Write-JCLog 'User chose Remind Me Later - the next command run prompts again'
                $finalStatus = 'Deferred'
                $issueReason = 'User deferred'
                $running = $false
            }
            'sign_out_now' {
                Write-JCLog 'User chose Sign Out Now'
                $noteText = 'User signed out immediately'
                $running = $false
            }
            'sign_out_later' {
                Write-JCLog 'User chose to sign out later'
                $noteText = 'User will sign out later'
                $running = $false
            }
            'closed' {
                Write-JCLog 'UI window was closed'
                if (-not $bindingSucceeded -and $finalStatus -ne 'Deferred') {
                    if ($BlockedCategory) {
                        $issueReason = "Blocked: $BlockedCategory"
                    }
                    elseif ($issueReason -eq 'None') {
                        $issueReason = 'User closed before completing'
                    }
                }
                $running = $false
            }
            default {
                Write-JCLog "Unknown UI action '$action' ignored" 'WARN'
            }
        }
        continue
    }

    if ((Get-Date) -gt $loopDeadline) {
        Write-JCLog 'Interaction timeout reached - treating as deferred.' 'WARN'
        $finalStatus = 'Deferred'
        $issueReason = 'Interaction timeout'
        break
    }

    # If the UI process disappears mid-flow (crash, kill, logoff), stop
    # waiting. Give it 90 seconds to start up first.
    if (((Get-Date) - $loopStart).TotalSeconds -gt 90 -and -not $bindingSucceeded) {
        if ((Get-HeartbeatAgeSeconds -Path $HbUiPath) -gt 60) {
            Write-JCLog 'UI heartbeat lost - assuming the UI is gone.' 'WARN'
            if ($issueReason -eq 'None') { $issueReason = 'UI exited unexpectedly' }
            break
        }
    }

    Start-Sleep -Milliseconds 400
}

# ---------------------------------------------------------------------
# Finalize: device description on failure (existing behavior), summary
# ---------------------------------------------------------------------
if ($bindingSucceeded) { $finalStatus = 'Good' }

if ($finalStatus -ne 'Good' -and $finalStatus -ne 'Deferred' -and -not $Simulated) {
    $descText = @(
        "BindingStatus: RequiresAction"
        "Issue: $issueReason"
        "DomainJoined: $($JoinState.IsDomainJoined)"
        "AzureADJoined: $($JoinState.IsAzureADJoined)"
        "MicrosoftAccount: $($JoinState.IsMSAccount)"
        "LocalUser: $effectiveLocal"
        "JCUser: $jcUsername"
        "Email: $cachedEmail"
    ) -join ' | '
    [void](Set-JCSystemDescription -ApiKey $ApiKey -BaseUri $BaseUri -SystemId $SystemId -Description $descText)
}

if ($TestMode) {
    # Remove IPC leftovers (they can contain the entered email). Real runs
    # delete the whole staging folder in Exit-JCEnrollment.
    foreach ($ipcFile in @($ReqPath, $StatusPath, $HbSysPath, $HbUiPath)) {
        Remove-Item -Path $ipcFile -Force -ErrorAction SilentlyContinue
    }
}

$summary = "Status: $finalStatus | Issue: $issueReason | User: $cachedEmail | LocalUser: $effectiveLocal | JCUser: $jcUsername | SystemID: $SystemId"
if ($noteText) { $summary = "$summary | Note: $noteText" }
Write-JCLog "===== Enrollment finished: $summary ====="
Write-Host $summary

if ($finalStatus -eq 'Good' -or $finalStatus -eq 'Deferred') { Exit-JCEnrollment 0 } else { Exit-JCEnrollment 1 }
